__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/6c7354085dbadc95.js",
  "static/chunks/turbopack-1c1ecac151a0c752.js"
])
