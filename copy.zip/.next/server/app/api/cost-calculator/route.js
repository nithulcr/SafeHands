var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cost-calculator/route.js")
R.c("server/chunks/[root-of-the-server]__73cb7a25._.js")
R.c("server/chunks/[root-of-the-server]__d615e5ef._.js")
R.m(32005)
R.m(62437)
module.exports=R.m(62437).exports
