module.exports=[72123,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js <module evaluation>"))},44536,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js"))},11153,a=>{"use strict";a.i(72123);var b=a.i(44536);a.n(b)},71618,(a,b,c)=>{b.exports=a.r(11153)},15753,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/app/SmoothScrollWrapper.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/app/SmoothScrollWrapper.tsx <module evaluation>","default")},86260,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/app/SmoothScrollWrapper.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/app/SmoothScrollWrapper.tsx","default")},46484,a=>{"use strict";a.i(15753);var b=a.i(86260);a.n(b)},27572,a=>{"use strict";a.s(["default",()=>f,"metadata",()=>e]);var b=a.i(7997),c=a.i(71618),d=a.i(46484);let e={title:"Safe Hands",description:"Safe Hands",keywords:"",icons:{icon:"/favicon.png",shortcut:"/favicon.png",apple:"/favicon.png"}};function f({children:a}){return(0,b.jsxs)("html",{lang:"en",dir:"ltr",children:[(0,b.jsxs)("head",{children:[(0,b.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Mona+Sans:ital,wght@0,200..900;1,200..900&display=swap",rel:"stylesheet"}),(0,b.jsx)(c.default,{async:!0,src:"https://www.googletagmanager.com/gtag/js?id=G-4L0PCEK1YL",strategy:"afterInteractive"}),(0,b.jsx)(c.default,{id:"google-gtag",strategy:"afterInteractive",children:`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-4L0PCEK1YL');
          `})]}),(0,b.jsxs)("body",{className:"antialiased mx-2 md:mx-5",children:[(0,b.jsx)(c.default,{id:"facebook-pixel",strategy:"afterInteractive",dangerouslySetInnerHTML:{__html:`
              !function(f,b,e,v,n,t,s)
              {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
              n.callMethod.apply(n,arguments):n.queue.push(arguments)};
              if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
              n.queue=[];t=b.createElement(e);t.async=!0;
              t.src=v;s=b.getElementsByTagName(e)[0];
              s.parentNode.insertBefore(t,s)}(window, document,'script',
              'https://connect.facebook.net/en_US/fbevents.js');
              fbq('init', '1567294114632706');
              fbq('track', 'PageView');
            `}}),(0,b.jsx)("noscript",{children:(0,b.jsx)("img",{height:"1",width:"1",style:{display:"none"},src:"https://www.facebook.com/tr?id=1567294114632706&ev=PageView&noscript=1"})}),(0,b.jsx)(d.default,{children:a})]})]})}}];

//# sourceMappingURL=_4a9b462e._.js.map