module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/components/AnimatedButton.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnimatedButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function AnimatedButton({ label, className = "", onClick, href, type, disabled }) {
    const buttonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const outlineRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Removed mouse move handlers and useEffect
    // Determine if link is external
    const isExternal = href && /^https?:\/\//i.test(href);
    if (href) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            ref: buttonRef,
            onClick: onClick,
            href: href,
            target: isExternal ? "_blank" : undefined,
            rel: isExternal ? "noopener noreferrer" : undefined,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("button", className),
            download: href?.endsWith(".pdf") ? true : undefined,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: outlineRef,
                className: "button-text flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-anim",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "first_text",
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 45,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "second_text",
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 46,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/AnimatedButton.tsx",
                        lineNumber: 44,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "btn-svg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "14",
                                height: "14",
                                viewBox: "0 0 14 14",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M11.1625 2.47132L1.19393 12.6461C1.05168 12.7912 0.972933 12.987 0.975014 13.1902C0.977094 13.3935 1.05983 13.5876 1.20502 13.7298C1.35021 13.8721 1.54596 13.9508 1.74921 13.9488C1.95246 13.9467 2.14656 13.8639 2.28881 13.7188L12.2574 3.54401L12.3372 11.4481C12.3393 11.6516 12.4221 11.8459 12.5675 11.9884C12.7129 12.1308 12.9089 12.2096 13.1124 12.2076C13.3159 12.2055 13.5102 12.1226 13.6526 11.9773C13.7951 11.8319 13.8739 11.6359 13.8718 11.4324L13.772 1.67829C13.7711 1.57749 13.7503 1.47785 13.7108 1.38509C13.6714 1.29233 13.614 1.20827 13.542 1.13773C13.47 1.06718 13.3847 1.01153 13.2912 0.973965C13.1976 0.936403 13.0976 0.917664 12.9968 0.918823L3.24271 1.01866C3.03921 1.02075 2.84486 1.10359 2.70244 1.24896C2.56001 1.39433 2.48116 1.59033 2.48325 1.79384C2.48533 1.99735 2.56817 2.19169 2.71354 2.33412C2.85892 2.47655 3.05492 2.55539 3.25842 2.55331L11.1625 2.47132Z",
                                    fill: "#0F0F0F"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                    lineNumber: 50,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 49,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "22",
                                height: "22",
                                viewBox: "0 0 24 24",
                                className: "whatsapp",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M19.05 4.90999C18.1331 3.9841 17.041 3.24996 15.8375 2.75036C14.634 2.25075 13.3431 1.99568 12.04 1.99999C6.57999 1.99999 2.12999 6.44999 2.12999 11.91C2.12999 13.66 2.58999 15.36 3.44999 16.86L2.04999 22L7.29999 20.62C8.74999 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.26999 20.92 6.77999 19.05 4.90999ZM12.04 20.15C10.56 20.15 9.10999 19.75 7.83999 19L7.53999 18.82L4.41999 19.64L5.24999 16.6L5.04999 16.29C4.22754 14.9771 3.79091 13.4593 3.78999 11.91C3.78999 7.36999 7.48999 3.66999 12.03 3.66999C14.23 3.66999 16.3 4.52999 17.85 6.08999C18.6176 6.85386 19.2259 7.76254 19.6396 8.76332C20.0533 9.76411 20.2642 10.8371 20.26 11.92C20.28 16.46 16.58 20.15 12.04 20.15ZM16.56 13.99C16.31 13.87 15.09 13.27 14.87 13.18C14.64 13.1 14.48 13.06 14.31 13.3C14.14 13.55 13.67 14.11 13.53 14.27C13.39 14.44 13.24 14.46 12.99 14.33C12.74 14.21 11.94 13.94 11 13.1C10.26 12.44 9.76999 11.63 9.61999 11.38C9.47999 11.13 9.59999 11 9.72999 10.87C9.83999 10.76 9.97999 10.58 10.1 10.44C10.22 10.3 10.27 10.19 10.35 10.03C10.43 9.85999 10.39 9.71999 10.33 9.59999C10.27 9.47999 9.76999 8.25999 9.56999 7.75999C9.36999 7.27999 9.15999 7.33999 9.00999 7.32999H8.52999C8.35999 7.32999 8.09999 7.38999 7.86999 7.63999C7.64999 7.88999 7.00999 8.48999 7.00999 9.70999C7.00999 10.93 7.89999 12.11 8.01999 12.27C8.13999 12.44 9.76999 14.94 12.25 16.01C12.84 16.27 13.3 16.42 13.66 16.53C14.25 16.72 14.79 16.69 15.22 16.63C15.7 16.56 16.69 16.03 16.89 15.45C17.1 14.87 17.1 14.38 17.03 14.27C16.96 14.16 16.81 14.11 16.56 13.99Z",
                                    fill: "#09424D"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                    lineNumber: 53,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 52,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/AnimatedButton.tsx",
                        lineNumber: 48,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                lineNumber: 43,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/components/AnimatedButton.tsx",
            lineNumber: 34,
            columnNumber: 9
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: buttonRef,
        onClick: onClick,
        disabled: disabled,
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("button", className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: outlineRef,
            className: "button-text flex items-center gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-anim",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "first_text",
                            children: label
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/AnimatedButton.tsx",
                            lineNumber: 71,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "second_text",
                            children: label
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/AnimatedButton.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/AnimatedButton.tsx",
                    lineNumber: 70,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "btn-svg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "14",
                            height: "14",
                            viewBox: "0 0 14 14",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M11.1625 2.47132L1.19393 12.6461C1.05168 12.7912 0.972933 12.987 0.975014 13.1902C0.977094 13.3935 1.05983 13.5876 1.20502 13.7298C1.35021 13.8721 1.54596 13.9508 1.74921 13.9488C1.95246 13.9467 2.14656 13.8639 2.28881 13.7188L12.2574 3.54401L12.3372 11.4481C12.3393 11.6516 12.4221 11.8459 12.5675 11.9884C12.7129 12.1308 12.9089 12.2096 13.1124 12.2076C13.3159 12.2055 13.5102 12.1226 13.6526 11.9773C13.7951 11.8319 13.8739 11.6359 13.8718 11.4324L13.772 1.67829C13.7711 1.57749 13.7503 1.47785 13.7108 1.38509C13.6714 1.29233 13.614 1.20827 13.542 1.13773C13.47 1.06718 13.3847 1.01153 13.2912 0.973965C13.1976 0.936403 13.0976 0.917664 12.9968 0.918823L3.24271 1.01866C3.03921 1.02075 2.84486 1.10359 2.70244 1.24896C2.56001 1.39433 2.48116 1.59033 2.48325 1.79384C2.48533 1.99735 2.56817 2.19169 2.71354 2.33412C2.85892 2.47655 3.05492 2.55539 3.25842 2.55331L11.1625 2.47132Z",
                                fill: "#0F0F0F"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 76,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/AnimatedButton.tsx",
                            lineNumber: 75,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            width: "22",
                            height: "22",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            className: "whatsapp",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M19.05 4.90999C18.1331 3.9841 17.041 3.24996 15.8375 2.75036C14.634 2.25075 13.3431 1.99568 12.04 1.99999C6.57999 1.99999 2.12999 6.44999 2.12999 11.91C2.12999 13.66 2.58999 15.36 3.44999 16.86L2.04999 22L7.29999 20.62C8.74999 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.26999 20.92 6.77999 19.05 4.90999ZM12.04 20.15C10.56 20.15 9.10999 19.75 7.83999 19L7.53999 18.82L4.41999 19.64L5.24999 16.6L5.04999 16.29C4.22754 14.9771 3.79091 13.4593 3.78999 11.91C3.78999 7.36999 7.48999 3.66999 12.03 3.66999C14.23 3.66999 16.3 4.52999 17.85 6.08999C18.6176 6.85386 19.2259 7.76254 19.6396 8.76332C20.0533 9.76411 20.2642 10.8371 20.26 11.92C20.28 16.46 16.58 20.15 12.04 20.15ZM16.56 13.99C16.31 13.87 15.09 13.27 14.87 13.18C14.64 13.1 14.48 13.06 14.31 13.3C14.14 13.55 13.67 14.11 13.53 14.27C13.39 14.44 13.24 14.46 12.99 14.33C12.74 14.21 11.94 13.94 11 13.1C10.26 12.44 9.76999 11.63 9.61999 11.38C9.47999 11.13 9.59999 11 9.72999 10.87C9.83999 10.76 9.97999 10.58 10.1 10.44C10.22 10.3 10.27 10.19 10.35 10.03C10.43 9.85999 10.39 9.71999 10.33 9.59999C10.27 9.47999 9.76999 8.25999 9.56999 7.75999C9.36999 7.27999 9.15999 7.33999 9.00999 7.32999H8.52999C8.35999 7.32999 8.09999 7.38999 7.86999 7.63999C7.64999 7.88999 7.00999 8.48999 7.00999 9.70999C7.00999 10.93 7.89999 12.11 8.01999 12.27C8.13999 12.44 9.76999 14.94 12.25 16.01C12.84 16.27 13.3 16.42 13.66 16.53C14.25 16.72 14.79 16.69 15.22 16.63C15.7 16.56 16.69 16.03 16.89 15.45C17.1 14.87 17.1 14.38 17.03 14.27C16.96 14.16 16.81 14.11 16.56 13.99Z",
                                fill: "#09424D"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/AnimatedButton.tsx",
                                lineNumber: 79,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/AnimatedButton.tsx",
                            lineNumber: 78,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/AnimatedButton.tsx",
                    lineNumber: 74,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/AnimatedButton.tsx",
            lineNumber: 69,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/AnimatedButton.tsx",
        lineNumber: 62,
        columnNumber: 7
    }, this);
}
}),
"[project]/src/app/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$AnimatedButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/AnimatedButton.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const navItems = [
    {
        href: "/",
        label: "Home"
    },
    {
        href: "/AboutUs",
        label: "About us"
    },
    {
        label: "Country",
        href: "#",
        submenu: [
            {
                href: "#",
                label: "Country1"
            },
            {
                href: "#",
                label: "Country2"
            }
        ]
    },
    {
        label: "Services",
        href: "/services",
        submenu: [
            {
                href: "/services/Document-Attestation-Overview",
                label: "Document Attestation Overview"
            },
            {
                href: "/services/Educational-Certificate-Attestation",
                label: "Educational Certificate Attestation"
            },
            {
                href: "/services/Personal-Document-Attestation",
                label: "Personal Document Attestation"
            },
            {
                href: "/services/Commercial-Document-Attestation",
                label: "Commercial Document Attestation"
            },
            {
                href: "/services/MOFA-Attestation",
                label: "MOFA Attestation (UAE)"
            },
            {
                href: "/services/Apostille-Services",
                label: "Apostille Services"
            },
            {
                href: "/services/True-Copy-Attestation",
                label: "True Copy Attestation"
            },
            {
                href: "/services/Police-Clearence-Certificate",
                label: "Police Clearence Certificate"
            },
            {
                href: "/services/Translation-Services",
                label: "Translation Services"
            },
            {
                href: "/services/Country-Specific-Attestation-Services",
                label: "Country Specific Attestation Services"
            },
            {
                href: "/services/UAE-Issued-Document",
                label: "UAE-Issued Document"
            },
            {
                href: "/services/Family-Visa-Documentation-Support",
                label: "Family Visa Documentation Support"
            },
            {
                href: "/services/Business-Setup-Services",
                label: "Business Setup Services"
            },
            {
                href: "/services/Pro-Services",
                label: "Pro Services"
            },
            {
                href: "/services/Golder-Visa-Support-Services",
                label: "Golder Visa Support Services"
            }
        ]
    },
    {
        href: "/blogs",
        label: "Blog"
    },
    {
        href: "/ContactUs",
        label: "Contact"
    }
];
function Header() {
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [animation, setAnimation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [scrolled, setScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openDropdowns, setOpenDropdowns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const handleMenuToggle = ()=>{
        if (open) {
            setAnimation("animate-menuSlideUp");
            setTimeout(()=>{
                setOpen(false);
                setAnimation(null);
            }, 300);
        } else {
            setOpen(true);
            setAnimation("animate-menuSlideDown");
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (pathname === "/") {
            document.body.classList.add("index-page");
        } else {
            document.body.classList.remove("index-page");
        }
    }, [
        pathname
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: [
            "content-center fixed top-0  left-0 z-50  transition-colors duration-300 bg-nav mx-2  md:mx-5 w-[-webkit-fill-available]",
            scrolled ? "bg-nav-cover" : "",
            pathname === "/" ? "index mt-2 md:mt-0" : ""
        ].filter(Boolean).join(" "),
        children: [
            pathname === "/" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full bg-[var(--siteColor)] hidden min-[990px]:block rounded-b-[16px]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-white grid grid-cols-2 items-center text-sm max-w-[1250px] mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-full max-w-[660px] flex items-center space-x-6 top-header-left relative ml-auto px-6 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-light",
                                        children: "Are you ready to grow up your business?"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 99,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "#",
                                        className: "flex items-center space-x-2 font-bold pr-5",
                                        children: [
                                            "Contact Us",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "ml-2",
                                                width: "16",
                                                height: "16",
                                                viewBox: "0 0 16 16",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M11.793 7.50002H2.5C2.36739 7.50002 2.24021 7.5527 2.14645 7.64647C2.05268 7.74024 2 7.86741 2 8.00002C2 8.13263 2.05268 8.25981 2.14645 8.35357C2.24021 8.44734 2.36739 8.50002 2.5 8.50002H11.793L8.146 12.146C8.05211 12.2399 7.99937 12.3672 7.99937 12.5C7.99937 12.6328 8.05211 12.7601 8.146 12.854C8.23989 12.9479 8.36722 13.0007 8.5 13.0007C8.63278 13.0007 8.76011 12.9479 8.854 12.854L13.354 8.35402C13.4006 8.30758 13.4375 8.2524 13.4627 8.19165C13.4879 8.13091 13.5009 8.06579 13.5009 8.00002C13.5009 7.93425 13.4879 7.86913 13.4627 7.80839C13.4375 7.74764 13.4006 7.69247 13.354 7.64602L8.854 3.14602C8.76011 3.05213 8.63278 2.99939 8.5 2.99939C8.36722 2.99939 8.23989 3.05213 8.146 3.14602C8.05211 3.23991 7.99937 3.36725 7.99937 3.50002C7.99937 3.6328 8.05211 3.76013 8.146 3.85402L11.793 7.50002Z",
                                                    fill: "white"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 102,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 100,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 98,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 97,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-w-[700px] h-full flex items-center justify-end overflow-hidden gap-8 relative px-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "items-center justify-center space-x-2 flex relative py-2 h-full pr-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "25",
                                                height: "25",
                                                viewBox: "0 0 25 25",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M12.7168 2.25537C18.2398 2.25537 22.7168 6.73237 22.7168 12.2554C22.7168 17.7784 18.2398 22.2554 12.7168 22.2554C7.1938 22.2554 2.7168 17.7784 2.7168 12.2554C2.7168 6.73237 7.1938 2.25537 12.7168 2.25537ZM12.7168 4.25537C10.5951 4.25537 8.56023 5.09823 7.05994 6.59852C5.55965 8.09881 4.7168 10.1336 4.7168 12.2554C4.7168 14.3771 5.55965 16.4119 7.05994 17.9122C8.56023 19.4125 10.5951 20.2554 12.7168 20.2554C14.8385 20.2554 16.8734 19.4125 18.3737 17.9122C19.8739 16.4119 20.7168 14.3771 20.7168 12.2554C20.7168 10.1336 19.8739 8.09881 18.3737 6.59852C16.8734 5.09823 14.8385 4.25537 12.7168 4.25537ZM12.7168 6.25537C12.9617 6.2554 13.1981 6.34533 13.3812 6.50809C13.5642 6.67085 13.6811 6.89512 13.7098 7.13837L13.7168 7.25537V11.8414L16.4238 14.5484C16.6031 14.7283 16.7073 14.9698 16.715 15.2238C16.7228 15.4777 16.6336 15.7251 16.4655 15.9156C16.2975 16.1062 16.0632 16.2257 15.8103 16.2498C15.5574 16.2739 15.3048 16.2008 15.1038 16.0454L15.0098 15.9624L12.0098 12.9624C11.8544 12.8068 11.7546 12.6044 11.7258 12.3864L11.7168 12.2554V7.25537C11.7168 6.99015 11.8222 6.7358 12.0097 6.54826C12.1972 6.36073 12.4516 6.25537 12.7168 6.25537Z",
                                                    fill: "white"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 114,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-light",
                                                children: "Working: 8.00am - 5.00pm"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 121,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 113,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-row gap-4 relative h-full header-top-social items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://x.com",
                                                "aria-label": "X",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className: "w-5 h-5",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "18",
                                                    height: "18",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M23.9281 12.1257C23.9281 5.68565 18.7015 0.458984 12.2615 0.458984C5.82147 0.458984 0.594803 5.68565 0.594803 12.1257C0.594803 17.7723 4.60814 22.474 9.92814 23.559V15.6257H7.5948V12.1257H9.92814V9.20899C9.92814 6.95732 11.7598 5.12565 14.0115 5.12565H16.9281V8.62565H14.5948C13.9531 8.62565 13.4281 9.15065 13.4281 9.79232V12.1257H16.9281V15.6257H13.4281V23.734C19.3198 23.1507 23.9281 18.1807 23.9281 12.1257Z",
                                                        fill: "white"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 125,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://x.com",
                                                "aria-label": "X",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className: "w-5 h-5",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "18",
                                                    height: "18",
                                                    viewBox: "0 0 20 21",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M11.028 0.977539C12.153 0.980539 12.724 0.986539 13.217 1.00054L13.411 1.00754C13.635 1.01554 13.856 1.02554 14.123 1.03754C15.187 1.08754 15.913 1.25554 16.55 1.50254C17.21 1.75654 17.766 2.10054 18.322 2.65554C18.8307 3.15527 19.2242 3.76001 19.475 4.42754C19.722 5.06454 19.89 5.79054 19.94 6.85554C19.952 7.12154 19.962 7.34254 19.97 7.56754L19.976 7.76154C19.991 8.25354 19.997 8.82454 19.999 9.94954L20 10.6955V12.0055C20.0024 12.7349 19.9948 13.4643 19.977 14.1935L19.971 14.3875C19.963 14.6125 19.953 14.8335 19.941 15.0995C19.891 16.1645 19.721 16.8895 19.475 17.5275C19.2242 18.1951 18.8307 18.7998 18.322 19.2995C17.8223 19.8082 17.2175 20.2017 16.55 20.4525C15.913 20.6995 15.187 20.8675 14.123 20.9175L13.411 20.9475L13.217 20.9535C12.724 20.9675 12.153 20.9745 11.028 20.9765L10.282 20.9775H8.97299C8.24325 20.9801 7.51351 20.9724 6.78399 20.9545L6.58999 20.9485C6.3526 20.9395 6.11526 20.9292 5.87799 20.9175C4.81399 20.8675 4.08799 20.6995 3.44999 20.4525C2.78282 20.2016 2.17843 19.8081 1.67899 19.2995C1.16993 18.7999 0.776098 18.1952 0.524989 17.5275C0.277989 16.8905 0.109989 16.1645 0.0599889 15.0995L0.0299889 14.3875L0.0249891 14.1935C0.0065551 13.4644 -0.00177913 12.735 -1.1037e-05 12.0055V9.94954C-0.00277893 9.22014 0.00455518 8.49074 0.021989 7.76154L0.028989 7.56754C0.036989 7.34254 0.046989 7.12154 0.058989 6.85554C0.108989 5.79054 0.276989 5.06554 0.523989 4.42754C0.775683 3.75974 1.17021 3.15498 1.67999 2.65554C2.17914 2.14709 2.78318 1.75361 3.44999 1.50254C4.08799 1.25554 4.81299 1.08754 5.87799 1.03754C6.14399 1.02554 6.36599 1.01554 6.58999 1.00754L6.78399 1.00154C7.51318 0.983772 8.24258 0.976104 8.97199 0.978539L11.028 0.977539ZM9.99999 5.97754C8.67391 5.97754 7.40214 6.50432 6.46446 7.44201C5.52677 8.37969 4.99999 9.65146 4.99999 10.9775C4.99999 12.3036 5.52677 13.5754 6.46446 14.5131C7.40214 15.4508 8.67391 15.9775 9.99999 15.9775C11.3261 15.9775 12.5978 15.4508 13.5355 14.5131C14.4732 13.5754 15 12.3036 15 10.9775C15 9.65146 14.4732 8.37969 13.5355 7.44201C12.5978 6.50432 11.3261 5.97754 9.99999 5.97754ZM9.99999 7.97754C10.394 7.97747 10.7841 8.05501 11.1481 8.20571C11.5121 8.35641 11.8428 8.57734 12.1215 8.85587C12.4001 9.13439 12.6211 9.46508 12.7719 9.82903C12.9228 10.193 13.0004 10.5831 13.0005 10.977C13.0006 11.371 12.923 11.7611 12.7723 12.1251C12.6216 12.4891 12.4007 12.8199 12.1222 13.0985C11.8436 13.3771 11.513 13.5982 11.149 13.749C10.785 13.8998 10.395 13.9775 10.001 13.9775C9.20534 13.9775 8.44228 13.6615 7.87967 13.0989C7.31706 12.5363 7.00099 11.7732 7.00099 10.9775C7.00099 10.1819 7.31706 9.41883 7.87967 8.85622C8.44228 8.29361 9.20534 7.97754 10.001 7.97754M15.251 4.47754C14.9195 4.47754 14.6015 4.60924 14.3671 4.84366C14.1327 5.07808 14.001 5.39602 14.001 5.72754C14.001 6.05906 14.1327 6.377 14.3671 6.61142C14.6015 6.84584 14.9195 6.97754 15.251 6.97754C15.5825 6.97754 15.9005 6.84584 16.1349 6.61142C16.3693 6.377 16.501 6.05906 16.501 5.72754C16.501 5.39602 16.3693 5.07808 16.1349 4.84366C15.9005 4.60924 15.5825 4.47754 15.251 4.47754Z",
                                                        fill: "white"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 133,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 131,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://www.instagram.com/safe handsuae/",
                                                "aria-label": "X",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className: "w-5 h-5",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "18",
                                                    height: "18",
                                                    viewBox: "0 0 18 19",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                            clipPath: "url(#clip0_1036_725)",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                                                                    id: "mask0_1036_725",
                                                                    maskUnits: "userSpaceOnUse",
                                                                    x: "0",
                                                                    y: "0",
                                                                    width: "18",
                                                                    height: "19",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        d: "M0 0.977539H18V18.9775H0V0.977539Z",
                                                                        fill: "white"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                                        lineNumber: 141,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                                    lineNumber: 140,
                                                                    columnNumber: 49
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                                                    mask: "url(#mask0_1036_725)",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        d: "M14.175 1.82129H16.9354L10.9054 8.73072L18 18.1344H12.4457L8.09229 12.4323L3.11657 18.1344H0.353571L6.80271 10.7416L0 1.82257H5.69571L9.62486 7.03357L14.175 1.82129ZM13.2043 16.4784H14.7343L4.86 3.39115H3.21943L13.2043 16.4784Z",
                                                                        fill: "white"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                                        lineNumber: 144,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                                    lineNumber: 143,
                                                                    columnNumber: 49
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Header.tsx",
                                                            lineNumber: 139,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                                                                id: "clip0_1036_725",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                                    width: "18",
                                                                    height: "18",
                                                                    fill: "white",
                                                                    transform: "translate(0 0.977539)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                                    lineNumber: 149,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/components/Header.tsx",
                                                                lineNumber: 148,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Header.tsx",
                                                            lineNumber: 147,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 137,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://linkedin.com",
                                                "aria-label": "Linkedin",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className: "w-5 h-5",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "24",
                                                    height: "24",
                                                    viewBox: "0 0 18 22",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M15 0.977539C15.7956 0.977539 16.5587 1.29361 17.1213 1.85622C17.6839 2.41883 18 3.18189 18 3.97754V15.9775C18 16.7732 17.6839 17.5363 17.1213 18.0989C16.5587 18.6615 15.7956 18.9775 15 18.9775H3C2.20435 18.9775 1.44129 18.6615 0.87868 18.0989C0.316071 17.5363 0 16.7732 0 15.9775V3.97754C0 3.18189 0.316071 2.41883 0.87868 1.85622C1.44129 1.29361 2.20435 0.977539 3 0.977539H15ZM5 7.97754C4.73478 7.97754 4.48043 8.0829 4.29289 8.27043C4.10536 8.45797 4 8.71232 4 8.97754V13.9775C4 14.2428 4.10536 14.4971 4.29289 14.6846C4.48043 14.8722 4.73478 14.9775 5 14.9775C5.26522 14.9775 5.51957 14.8722 5.70711 14.6846C5.89464 14.4971 6 14.2428 6 13.9775V8.97754C6 8.71232 5.89464 8.45797 5.70711 8.27043C5.51957 8.0829 5.26522 7.97754 5 7.97754ZM8 6.97754C7.73478 6.97754 7.48043 7.0829 7.29289 7.27043C7.10536 7.45797 7 7.71232 7 7.97754V13.9775C7 14.2428 7.10536 14.4971 7.29289 14.6846C7.48043 14.8722 7.73478 14.9775 8 14.9775C8.26522 14.9775 8.51957 14.8722 8.70711 14.6846C8.89464 14.4971 9 14.2428 9 13.9775V10.3175C9.305 9.97354 9.82 9.56954 10.393 9.32454C10.726 9.18254 11.227 9.12454 11.575 9.23454C11.6904 9.26383 11.7933 9.3298 11.868 9.42254C11.92 9.49254 12 9.64854 12 9.97754V13.9775C12 14.2428 12.1054 14.4971 12.2929 14.6846C12.4804 14.8722 12.7348 14.9775 13 14.9775C13.2652 14.9775 13.5196 14.8722 13.7071 14.6846C13.8946 14.4971 14 14.2428 14 13.9775V9.97754C14 9.30754 13.83 8.71154 13.476 8.23354C13.1503 7.8001 12.6944 7.48226 12.175 7.32654C11.273 7.04354 10.274 7.20054 9.607 7.48654C9.39347 7.57838 9.18545 7.68256 8.984 7.79854C8.94208 7.56813 8.82062 7.35974 8.6408 7.2097C8.46097 7.05967 8.23419 6.9775 8 6.97754ZM5 4.97754C4.73478 4.97754 4.48043 5.0829 4.29289 5.27043C4.10536 5.45797 4 5.71232 4 5.97754C4 6.24276 4.10536 6.49711 4.29289 6.68465C4.48043 6.87218 4.73478 6.97754 5 6.97754C5.26522 6.97754 5.51957 6.87218 5.70711 6.68465C5.89464 6.49711 6 6.24276 6 5.97754C6 5.71232 5.89464 5.45797 5.70711 5.27043C5.51957 5.0829 5.26522 4.97754 5 4.97754Z",
                                                        fill: "white"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 157,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 156,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 155,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 123,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 112,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 111,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/Header.tsx",
                    lineNumber: 96,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header.tsx",
                lineNumber: 95,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "second-header  w-full border-b bg-[#fff] rounded-b-[16px] border-b-[rgba(0,0,0,0.1)] " + (scrolled ? "rounded-b-[16px] bg-[#fff]" : "bg-[var(--background2)]") + (pathname === "/" ? " md:mt-3 rounded-t-[16px]" : "rounded-b-[16px]"),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-[1250px] mx-auto flex items-center justify-between md:px-6 px-3 h-[80px] main-header z-10 relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-2xl font-bold h-full align-content-center flex",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "items-center flex",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/logo.png",
                                    alt: "Logo",
                                    width: 120,
                                    height: 50,
                                    className: "w-[135px]"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Header.tsx",
                                    lineNumber: 179,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 178,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 177,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "items-center gap-6 hidden md:flex h-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                className: "hidden lg:flex gap-6 h-full",
                                children: navItems.map((item)=>item.submenu ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative h-full flex items-center",
                                        onMouseEnter: ()=>setOpenDropdowns((prev)=>({
                                                    ...prev,
                                                    [item.label]: true
                                                })),
                                        onMouseLeave: ()=>setOpenDropdowns((prev)=>({
                                                    ...prev,
                                                    [item.label]: false
                                                })),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: item.href,
                                                className: `place-items-center h-full flex transition-colors duration-300 font-light text-md menu-item ${pathname === item.href ? "menu-active" : ""}`,
                                                children: [
                                                    item.label,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                        size: 16,
                                                        className: `ml-1 transition-transform duration-300 ${openDropdowns[item.label] ? "rotate-180" : ""}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 199,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 193,
                                                columnNumber: 41
                                            }, this),
                                            openDropdowns[item.label] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                animate: {
                                                    opacity: 1,
                                                    y: 0
                                                },
                                                transition: {
                                                    duration: 0.2
                                                },
                                                className: "absolute top-full left-1/2 -translate-x-1/2 w-[60vw] max-w-4xl bg-white rounded-b-md shadow-lg z-60",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-6 grid grid-cols-3 gap-x-8",
                                                    children: item.submenu.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            href: subItem.href,
                                                            className: `block py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md px-4 ${pathname === subItem.href ? "text-[var(--siteColor)] font-semibold" : ""}`,
                                                            children: subItem.label
                                                        }, subItem.label, false, {
                                                            fileName: "[project]/src/app/components/Header.tsx",
                                                            lineNumber: 210,
                                                            columnNumber: 57
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 208,
                                                    columnNumber: 49
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 202,
                                                columnNumber: 45
                                            }, this)
                                        ]
                                    }, `${item.label}-${item.href}`, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 186,
                                        columnNumber: 37
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: item.href,
                                        className: `place-items-center flex transition-colors duration-300 font-light text-md menu-item ${pathname === item.href ? "menu-active" : ""}`,
                                        children: item.label
                                    }, `${item.label}-${item.href}`, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 224,
                                        columnNumber: 37
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 183,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 182,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$AnimatedButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "https://wa.me/0509548130",
                                        label: "Let's Chat",
                                        className: "w-fit whatsapp-btn"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 240,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Header.tsx",
                                    lineNumber: 239,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleMenuToggle,
                                    className: "lg:hidden text-black",
                                    children: open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                        size: 28,
                                        strokeWidth: 1
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 243,
                                        columnNumber: 37
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        size: 28,
                                        strokeWidth: 1
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 243,
                                        columnNumber: 71
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Header.tsx",
                                    lineNumber: 242,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 238,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/Header.tsx",
                    lineNumber: 176,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header.tsx",
                lineNumber: 169,
                columnNumber: 13
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 20
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.5
                },
                className: `lg:hidden bg-[var(--background2)] font-light px-6 py-8 space-y-3 shadow-md transition-all duration-300 origin-top ${animation}`,
                children: navItems.map((item)=>item.submenu ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center ",
                                onClick: ()=>setOpenDropdowns((prev)=>({
                                            ...prev,
                                            [item.label]: !openDropdowns[item.label]
                                        })),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 262,
                                        columnNumber: 37
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                        size: 16,
                                        className: `ml-1 transition-transform duration-300 ${openDropdowns[item.label] ? "rotate-180" : ""}`
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 263,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 258,
                                columnNumber: 33
                            }, this),
                            openDropdowns[item.label] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pl-4 mt-2 space-y-2",
                                children: item.submenu.map((subItem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: subItem.href,
                                        className: `block ${pathname === subItem.href ? "font-semibold" : ""}`,
                                        children: subItem.label
                                    }, subItem.label, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 268,
                                        columnNumber: 45
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 266,
                                columnNumber: 37
                            }, this)
                        ]
                    }, item.href, true, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 257,
                        columnNumber: 29
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: item.href,
                        className: `block hover:text-[var(--siteColor)] ${pathname === item.href ? "text-[var(--siteColor)] font-semibold" : ""}`,
                        children: item.label
                    }, item.href, false, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 281,
                        columnNumber: 29
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/components/Header.tsx",
                lineNumber: 249,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Header.tsx",
        lineNumber: 85,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/components/ServicesFull.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$AnimatedButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/AnimatedButton.tsx [app-ssr] (ecmascript)");
"use client";
;
;
const ServicesFullDataEn = [
    {
        id: "01",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "50",
            height: "50",
            viewBox: "0 0 50 50",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M38.26 0.851562C38.6204 1.09311 38.747 1.41773 38.7457 1.86121C38.7316 6.80467 38.7367 11.7494 38.7367 16.6929C38.7367 16.7887 38.7418 16.8846 38.7329 16.9804C38.6946 17.3996 38.3865 17.6872 37.9789 17.6897C37.5699 17.6936 37.2529 17.4086 37.2133 16.9932C37.2005 16.8513 37.2095 16.7069 37.2095 16.5625C37.2095 12.0497 37.2095 7.5357 37.2095 3.02295C37.2095 2.83252 37.2095 2.64209 37.2095 2.41716C27.5194 2.41716 17.8523 2.41716 8.12259 2.41716C8.12259 2.58075 8.12259 2.74945 8.12259 2.91943C8.12259 4.46586 8.12387 6.01356 8.12131 7.55999C8.12004 8.25268 7.86571 8.50446 7.16917 8.50574C5.46555 8.50701 3.7632 8.50574 2.03018 8.50574C2.03018 21.782 2.03018 35.0238 2.03018 48.3166C2.22828 48.3166 2.41487 48.3166 2.60146 48.3166C11.2436 48.3166 19.8857 48.3166 28.5265 48.3166C28.6696 48.3166 28.814 48.309 28.9572 48.3205C29.3802 48.3537 29.6678 48.6553 29.6742 49.0668C29.6805 49.4963 29.384 49.8107 28.938 49.8426C28.8268 49.8503 28.7143 49.8452 28.6032 49.8452C19.5789 49.8452 10.5547 49.8426 1.53047 49.8528C1.07932 49.8528 0.722748 49.7544 0.47353 49.3685C0.469696 35.3957 0.469696 21.4254 0.469696 7.45391C1.75412 6.15542 3.03472 4.8531 4.32554 3.55973C5.23295 2.64976 6.15569 1.75386 7.07077 0.851562C17.4676 0.851562 27.8632 0.851562 38.26 0.851562ZM6.58383 3.68753C5.49367 4.77258 4.38177 5.88064 3.31589 6.94014C4.34215 6.94014 5.45788 6.94014 6.58383 6.94014C6.58383 5.80907 6.58383 4.7138 6.58383 3.68753Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M49.4697 23.2735C49.3866 25.3299 48.5828 26.8967 46.9635 28.0227C45.0988 29.3199 43.4795 30.8574 42.2999 32.8179C41.3005 34.4793 40.9695 36.312 40.9886 38.2201C40.9899 38.4067 41.1484 38.6176 41.2839 38.7735C41.9804 39.5774 42.7523 40.3251 43.3875 41.175C44.1416 42.1859 44.2604 43.2543 43.5153 44.4071C42.6437 45.7555 41.8679 47.169 41.096 48.5787C40.618 49.4528 39.8767 49.7953 38.9463 49.8375C37.4357 49.9065 36.0107 49.495 34.6253 48.9659C30.9254 47.5537 27.568 45.5791 24.7499 42.7661C23.9255 41.9431 23.1447 41.0472 22.9555 39.8433C22.8916 39.433 22.953 38.9256 23.1485 38.5665C24.0597 36.8884 25.0259 35.2398 25.9985 33.5949C26.5673 32.6326 27.5462 32.4894 28.5124 32.5929C29.5489 32.7029 30.5726 32.9623 31.5874 33.2166C31.9746 33.3138 32.2609 33.2933 32.6073 33.0927C35.3921 31.4836 36.9807 29.0221 37.6785 25.951C37.9456 24.7765 38.0645 23.5674 38.2562 22.375C38.6895 19.6937 41.0449 17.7025 43.7875 17.6948C46.5481 17.6872 48.9048 19.6439 49.3572 22.3239C49.4135 22.669 49.4403 23.0192 49.4697 23.2735ZM39.4179 37.1517C39.4218 37.1402 39.4473 37.0993 39.455 37.0546C39.4754 36.9293 39.4895 36.8015 39.5023 36.675C39.6659 34.9727 40.1413 33.37 41.0423 31.9066C42.3178 29.8375 44.0227 28.1875 46.0037 26.8034C47.453 25.7912 48.1086 24.4186 47.8415 22.646C47.5475 20.6957 45.766 19.1991 43.7824 19.2234C41.7721 19.2489 40.0544 20.7506 39.7719 22.7073C39.5994 23.9023 39.4716 25.11 39.193 26.2807C38.5655 28.9199 37.4191 31.2855 35.2809 33.0645C34.8553 33.4186 34.4106 33.7508 34.0387 34.0422C35.8164 35.0711 37.6031 36.1037 39.4179 37.1517ZM40.6282 46.2705C41.2021 45.2762 41.7363 44.3164 42.305 43.3783C42.5044 43.0499 42.5389 42.7342 42.3395 42.4415C41.9369 41.8523 41.5548 41.2299 41.0551 40.7302C38.3533 38.0233 35.1173 36.1523 31.5554 34.827C30.4499 34.4154 29.315 34.1049 28.1137 34.1266C27.6561 34.1355 27.3456 34.2812 27.1194 34.7107C26.6823 35.5414 26.189 36.3427 25.7212 37.1581C25.6535 37.2757 25.6011 37.4022 25.5372 37.5338C31.627 38.633 37.1635 41.8357 40.6282 46.2705ZM25.5129 38.9819C25.5001 39.0279 25.4886 39.0752 25.4758 39.1212C25.3966 39.1212 25.3161 39.1186 25.2368 39.1212C24.415 39.1442 24.2399 39.4036 24.6668 40.1142C25.0004 40.6689 25.3851 41.2159 25.8439 41.6683C28.8358 44.6167 32.3836 46.6552 36.3775 47.9064C37.1699 48.1543 38.0287 48.254 38.862 48.2847C39.6454 48.3141 39.8039 48.0163 39.4013 47.3517C39.0332 46.7447 38.6064 46.1491 38.1041 45.6519C35.4701 43.0473 32.3427 41.2056 28.8933 39.9136C27.8057 39.5046 26.6427 39.2873 25.5129 38.9819Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M11.4429 15.3355C11.4366 10.7396 15.1671 6.98986 19.7553 6.98219C24.3792 6.97325 28.1175 10.7051 28.1188 15.3278C28.1201 19.9287 24.4086 23.6644 19.8103 23.69C15.2234 23.7156 11.4506 19.9479 11.4429 15.3355ZM19.7476 22.118C23.4961 22.1346 26.5698 19.1172 26.5903 15.4019C26.6107 11.624 23.5549 8.52734 19.7975 8.51967C16.0937 8.51073 13.0111 11.5525 12.9932 15.2332C12.974 19.0609 15.957 22.1027 19.7476 22.118Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19.7412 28.7255C15.3269 28.7255 10.9126 28.7255 6.4982 28.7255C6.33845 28.7255 6.1787 28.7307 6.02022 28.7166C5.56651 28.677 5.26106 28.3639 5.2649 27.951C5.26873 27.5676 5.57163 27.2392 5.98443 27.1868C6.1263 27.1689 6.27071 27.1778 6.41385 27.1778C15.3218 27.1778 24.231 27.1778 33.1389 27.1778C33.314 27.1778 33.4955 27.1625 33.6629 27.2008C34.0693 27.2954 34.3134 27.574 34.293 27.9856C34.2738 28.3894 34.0387 28.6667 33.6041 28.7102C33.4303 28.7268 33.2539 28.7243 33.0789 28.7255C28.6338 28.7255 24.1875 28.7255 19.7412 28.7255Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14.0949 33.7727C11.5298 33.7727 8.96609 33.7727 6.40107 33.7727C6.24131 33.7727 6.08028 33.7816 5.92436 33.7612C5.54223 33.7113 5.25083 33.379 5.26873 33.0033C5.2879 32.6071 5.50644 32.3528 5.88985 32.2582C6.01127 32.2288 6.1429 32.2429 6.27071 32.2429C11.4953 32.2429 16.72 32.2429 21.9446 32.2429C22.0558 32.2429 22.1695 32.2352 22.2781 32.2493C22.6884 32.3017 22.9721 32.6314 22.9466 33.0391C22.921 33.4634 22.6858 33.7113 22.2654 33.765C22.1082 33.7855 21.9471 33.774 21.7874 33.774C19.2236 33.774 16.6599 33.7727 14.0949 33.7727Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M13.6182 42.4952C16.0554 42.4952 18.4926 42.4926 20.9298 42.499C21.1484 42.499 21.4308 42.485 21.5701 42.6064C21.7733 42.784 21.9944 43.0856 21.9816 43.3221C21.9689 43.5572 21.712 43.8231 21.4947 43.9879C21.3554 44.094 21.0972 44.0582 20.8915 44.0582C16.0656 44.0608 11.2385 44.0608 6.41258 44.0608C5.65598 44.0608 5.26746 43.7962 5.2649 43.285C5.26235 42.7751 5.66365 42.4939 6.40364 42.4939C8.80763 42.4952 11.2129 42.4952 13.6182 42.4952Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12.914 37.3C15.1774 37.3 17.4408 37.2974 19.7029 37.3025C20.2307 37.3038 20.5541 37.608 20.5528 38.063C20.5515 38.5103 20.2141 38.8144 19.6978 38.8349C19.6505 38.8362 19.6019 38.8349 19.5547 38.8349C15.1237 38.8349 10.6927 38.8349 6.26178 38.8336C5.67132 38.8336 5.33009 38.5946 5.26874 38.1524C5.201 37.6629 5.57419 37.3012 6.16976 37.3C8.41911 37.2974 10.6659 37.3 12.914 37.3Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M18.8504 17.6641C19.6211 16.7733 20.3687 15.9081 21.1164 15.0428C21.6263 14.4524 22.1299 13.8543 22.6475 13.2702C23.0207 12.8497 23.4654 12.796 23.8156 13.104C24.176 13.421 24.1824 13.8504 23.8079 14.2875C22.4277 15.8966 21.0448 17.5031 19.6569 19.1044C19.2569 19.5658 18.9335 19.6093 18.4479 19.2744C17.7002 18.7594 16.9589 18.2354 16.2228 17.705C15.7614 17.3727 15.672 16.9458 15.9582 16.5586C16.2215 16.2007 16.6675 16.1483 17.1021 16.4436C17.6772 16.8334 18.2446 17.2398 18.8504 17.6641Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Document Attestation Overview "
        }, void 0, false),
        description: "Document attestation is the process of validating a document’s authenticity so it can be legally accepted in another country.",
        link: "/services/Document-Attestation-Overview"
    },
    {
        id: "02",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "45",
            height: "58",
            viewBox: "0 0 45 58",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1036_178)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M23.3989 0.674805C24.1589 1.50169 24.9411 2.30924 25.6759 3.15843C27.7005 5.49929 29.7088 7.85502 31.7171 10.2107C31.8833 10.4056 32.06 10.6168 32.146 10.8517C32.4236 11.6117 31.8996 12.3598 31.0476 12.3954C30.2194 12.4311 29.3882 12.4029 28.508 12.4029C28.4946 12.6379 28.4753 12.8163 28.4753 12.9933C28.4738 16.1283 28.4827 19.2648 28.4634 22.3999C28.4605 22.8282 28.6119 23.0126 28.9889 23.1658C30.111 23.6223 30.0932 23.6268 30.9541 22.7955C31.5909 22.1797 32.2663 21.6057 32.9134 21.0004C33.0055 20.9141 33.0678 20.755 33.0738 20.6271C33.0945 20.239 33.0812 19.8493 33.0812 19.3674C32.5542 19.3674 32.0436 19.3556 31.5345 19.3704C30.9705 19.3883 30.4999 19.2291 30.2476 18.6923C29.9967 18.1584 30.16 17.6988 30.5355 17.2675C32.5572 14.949 34.5655 12.617 36.5872 10.297C37.2165 9.57422 37.9587 9.58017 38.5806 10.3044C40.5741 12.6245 42.5571 14.9519 44.5491 17.272C44.9172 17.7003 45.0924 18.1613 44.8252 18.6997C44.5743 19.2039 44.1365 19.3868 43.5873 19.3704C43.1078 19.3556 42.6269 19.3674 42.0614 19.3674C42.0614 19.5876 42.0614 19.7824 42.0614 19.9772C42.0614 24.1518 42.0658 28.3264 42.054 32.5009C42.0525 32.8757 42.1178 33.1494 42.4325 33.4052C43.0099 33.8751 43.2518 34.5414 43.2607 35.2761C43.2756 36.6487 43.2815 38.0214 43.2607 39.3941C43.2384 40.8709 42.1534 41.9343 40.6735 41.9566C39.915 41.9685 39.1551 41.9759 38.3966 41.9536C37.8741 41.9387 37.5668 42.1692 37.3917 42.6466C37.2388 43.063 37.0547 43.4676 36.8825 43.8765C36.7044 44.2974 36.7638 44.6618 37.1007 44.989C37.6589 45.5318 38.211 46.0806 38.7498 46.6412C39.7918 47.7239 39.7933 49.1933 38.7409 50.273C37.7835 51.256 36.8158 52.2272 35.8331 53.1849C34.7985 54.1933 33.3424 54.2007 32.293 53.2117C31.7275 52.6778 31.1783 52.1246 30.6409 51.5609C30.2684 51.1698 29.8646 51.0999 29.3896 51.3319C29.1907 51.4286 28.9874 51.5193 28.7826 51.604C27.555 52.1112 27.558 52.1097 27.5535 53.466C27.552 54.1144 27.5713 54.7673 27.5179 55.4128C27.4095 56.7141 26.372 57.6584 25.0702 57.6674C23.6438 57.6763 22.2188 57.6778 20.7924 57.6659C19.5693 57.6555 18.5214 56.7617 18.3997 55.5451C18.3121 54.6632 18.3314 53.7679 18.3418 52.8786C18.3492 52.3179 18.1369 51.9565 17.6011 51.7885C17.4779 51.7498 17.3562 51.7052 17.2374 51.6531C15.6329 50.9378 15.8347 50.9973 14.6042 52.2183C14.2747 52.544 13.9556 52.8816 13.6186 53.1983C12.5648 54.1903 11.1101 54.2022 10.0785 53.2013C9.06768 52.2212 8.07021 51.2248 7.09501 50.209C6.11535 49.1903 6.12277 47.7329 7.09204 46.7007C7.63827 46.1207 8.20677 45.5601 8.77972 45.0068C9.13596 44.6618 9.19088 44.284 8.99495 43.8468C8.9044 43.6445 8.80792 43.4438 8.73074 43.2356C8.19638 41.7826 8.1563 41.967 6.79666 41.961C6.25933 41.958 5.722 41.9699 5.18616 41.958C3.73893 41.9253 2.65983 40.8635 2.63608 39.4164C2.61381 38.0437 2.62272 36.671 2.63311 35.2984C2.63905 34.4744 2.97747 33.8067 3.59495 33.252C3.76862 33.0958 3.87549 32.8132 3.91705 32.5723C3.97346 32.2481 3.92596 31.906 3.94229 31.5729C3.96752 31.0851 4.26884 30.8368 4.72156 30.7847C5.14311 30.7356 5.55427 31.0896 5.59583 31.5432C5.62849 31.9105 5.60325 32.2823 5.60325 32.7181C6.34839 32.7181 7.0668 32.7612 7.77334 32.6928C8.00787 32.6705 8.28692 32.3998 8.41754 32.1693C8.67136 31.7216 8.84355 31.2264 9.03206 30.7445C9.18791 30.3445 9.11369 29.989 8.79753 29.6797C8.25427 29.1488 7.71842 28.6089 7.18852 28.0646C6.09011 26.9403 6.08566 25.4754 7.18703 24.3526C8.10732 23.4126 9.04096 22.4846 9.97758 21.5596C10.1601 21.3781 10.3576 21.1566 10.5876 21.0896C11.1873 20.9141 11.2556 20.5126 11.2021 19.9891C11.1695 19.6768 11.1903 19.3585 11.1977 19.0432C11.2185 18.1346 11.6608 17.7033 12.5826 17.6884C12.8364 17.6839 13.0902 17.6884 13.5029 17.6884C11.7588 15.6494 10.1082 13.7176 8.40715 11.7292C6.6972 13.7012 5.01694 15.6361 3.23426 17.6929C3.71667 17.6929 4.05807 17.681 4.39798 17.6958C5.12233 17.7256 5.60028 18.1643 5.60325 18.8767C5.61661 21.8079 5.61364 24.7392 5.60474 27.6705C5.60325 28.2089 5.2203 28.5822 4.74828 28.5732C4.26884 28.5628 3.93783 28.2074 3.93635 27.6363C3.92744 25.1318 3.9319 22.6274 3.9319 20.1229C3.9319 19.9028 3.9319 19.6827 3.9319 19.3704C3.36934 19.3704 2.84091 19.3615 2.31398 19.3734C1.74251 19.3868 1.30018 19.189 1.05675 18.6476C0.819257 18.1182 1.00777 17.6795 1.35955 17.2735C3.35301 14.9787 5.33904 12.678 7.33547 10.3862C8.06873 9.54448 8.7441 9.54299 9.47439 10.3907C11.4485 12.6795 13.4049 14.9817 15.3761 17.2705C15.7487 17.7033 15.906 18.1643 15.6566 18.6982C15.4162 19.2128 14.9694 19.3853 14.4231 19.3719C13.9452 19.36 13.4658 19.3689 12.9106 19.3689C12.9106 19.8657 12.9017 20.3207 12.918 20.7758C12.921 20.868 12.9967 20.9766 13.0694 21.045C13.7804 21.7187 14.5152 22.3686 15.2069 23.0617C15.6136 23.4692 15.9832 23.5301 16.5443 23.3442C17.3591 23.0736 17.659 22.6393 17.5566 21.7782C17.4645 21.0093 17.5343 20.2226 17.5388 19.4433C17.5432 18.728 17.8683 18.3041 18.4011 18.31C18.9325 18.3145 19.2487 18.7324 19.2502 19.4597C19.2546 22.0578 19.2517 24.6545 19.2517 27.2526C19.2517 27.4712 19.2517 27.6913 19.2517 28.0021C21.7721 27.0771 24.2286 27.0726 26.7683 28.0616C26.7683 27.7835 26.7683 27.5753 26.7683 27.3671C26.7683 22.3582 26.7683 17.3478 26.7683 12.3389C26.7683 11.106 27.1646 10.7134 28.3981 10.7119C28.8568 10.7119 29.3169 10.7119 29.9225 10.7119C27.5758 7.96953 25.3077 5.31934 23.0041 2.6275C20.6781 5.30893 18.3789 7.95912 15.9921 10.7119C16.6927 10.7119 17.2582 10.7075 17.8252 10.7134C18.7663 10.7223 19.2324 11.167 19.2487 12.1054C19.265 13.0885 19.2606 14.0715 19.2487 15.0546C19.2413 15.6985 18.9147 16.0911 18.4145 16.106C17.895 16.1209 17.5462 15.706 17.5402 15.0412C17.5328 14.1905 17.5388 13.3398 17.5388 12.4073C16.6259 12.4073 15.7605 12.4311 14.8966 12.4014C14.0506 12.3716 13.5415 11.7158 13.7418 10.9439C13.7953 10.7387 13.9185 10.5335 14.0595 10.3714C16.7268 7.28691 19.3986 4.20691 22.0764 1.13138C22.2292 0.955886 22.4385 0.826499 22.6211 0.676292C22.8809 0.674805 23.1406 0.674805 23.3989 0.674805ZM28.4738 24.8285C28.4738 26.0346 28.4916 27.2005 28.4649 28.365C28.4545 28.7933 28.5807 29.0595 28.9369 29.3272C34.2775 33.3427 34.2954 41.2873 28.9829 45.3325C27.8504 46.1951 26.5932 46.8093 25.1934 47.0948C24.6309 47.2094 24.2464 46.9536 24.1366 46.4643C24.0386 46.0196 24.2954 45.6285 24.8016 45.4634C24.9767 45.4069 25.1593 45.3727 25.3374 45.3221C28.9087 44.2989 31.4662 40.7147 31.2762 37.0012C31.0565 32.6779 27.7509 29.3198 23.4271 29.0268C17.8223 28.6476 13.4079 34.0387 14.9204 39.461C15.7798 42.544 17.8044 44.5205 20.8726 45.4098C21.7068 45.6523 22.014 45.969 21.8685 46.5267C21.7201 47.0963 21.2644 47.2882 20.4673 47.0562C16.6259 45.9363 14.101 43.4467 13.2179 39.5458C12.3154 35.5675 13.5533 32.1693 16.6912 29.5682C17.3651 29.009 17.6026 28.4944 17.5521 27.6779C17.4927 26.7276 17.5388 25.7699 17.5388 24.8195C17.423 24.8195 17.3844 24.8121 17.3502 24.821C17.2968 24.8344 17.2449 24.8537 17.1944 24.876C15.9594 25.4456 14.8996 25.1824 13.9749 24.2157C13.5014 23.7205 13.013 23.2371 12.5217 22.7598C12.0571 22.3091 11.6311 22.3076 11.1695 22.7627C10.2462 23.6744 9.33041 24.5935 8.42051 25.517C7.92771 26.0182 7.9292 26.4064 8.41606 26.9061C8.9712 27.4772 9.55751 28.02 10.0963 28.6059C10.8088 29.3793 11.0166 30.2776 10.6292 31.2785C10.4155 31.8302 10.2002 32.3834 9.94789 32.9173C9.49517 33.8721 8.72925 34.3822 7.66499 34.4001C6.92431 34.412 6.18363 34.4001 5.44295 34.4031C4.62359 34.406 4.33118 34.6841 4.32376 35.4976C4.31337 36.7216 4.31337 37.9456 4.32376 39.171C4.3297 39.9994 4.59688 40.2507 5.44295 40.2626C6.25784 40.2745 7.07274 40.2507 7.88467 40.2968C8.85839 40.3519 9.54118 40.8798 9.94937 41.7543C10.1676 42.2228 10.3442 42.7121 10.552 43.185C11.0493 44.3197 10.8355 45.3162 9.985 46.1906C9.46845 46.7216 8.93261 47.2361 8.41754 47.7686C7.9292 48.2727 7.92771 48.6594 8.42051 49.1591C9.31705 50.0707 10.221 50.975 11.1309 51.8747C11.6489 52.3878 12.0467 52.3848 12.5662 51.8762C13.1229 51.3319 13.6572 50.7653 14.2228 50.2299C15.0302 49.464 15.9698 49.3197 16.9955 49.7108C17.4438 49.8819 17.8831 50.0782 18.3269 50.2596C19.4639 50.7236 20.025 51.5832 20.0443 52.8012C20.0562 53.5434 20.0413 54.2855 20.0488 55.0276C20.0562 55.682 20.3456 55.9928 20.9883 55.9987C22.3035 56.0106 23.6171 56.0121 24.9322 55.9987C25.5452 55.9928 25.8495 55.676 25.8569 55.0663C25.8673 54.2691 25.8376 53.4705 25.8673 52.6733C25.9074 51.5773 26.4195 50.7712 27.4407 50.3251C27.9142 50.1183 28.3922 49.919 28.8731 49.7272C29.9418 49.3019 30.9051 49.4714 31.7364 50.276C32.2692 50.792 32.7828 51.3259 33.3098 51.8479C33.8545 52.3848 34.2508 52.3937 34.7852 51.8643C35.6802 50.9779 36.5708 50.0856 37.457 49.1888C37.9899 48.649 37.9795 48.2697 37.4362 47.7165C36.9167 47.1871 36.3808 46.674 35.8687 46.1386C35.0568 45.2894 34.8653 44.3153 35.3314 43.2237C35.4991 42.8325 35.6773 42.4459 35.8257 42.0473C36.274 40.8412 37.1468 40.2641 38.4173 40.2626C39.1387 40.2626 39.8616 40.273 40.583 40.2567C41.2925 40.2403 41.5508 39.9771 41.5567 39.2647C41.5656 37.9842 41.5656 36.7053 41.5567 35.4248C41.5522 34.6812 41.2598 34.406 40.4954 34.4016C39.7547 34.3971 39.014 34.4075 38.2734 34.3986C37.1616 34.3852 36.3779 33.8573 35.9222 32.8489C35.7159 32.3939 35.5392 31.9269 35.3418 31.4688C34.8624 30.3579 35.0553 29.3719 35.8925 28.5108C36.409 27.9798 36.9434 27.4638 37.4614 26.9343C37.975 26.4108 37.9795 26.0182 37.4703 25.5022C36.5723 24.592 35.6684 23.6863 34.76 22.788C34.2582 22.2913 33.8456 22.3002 33.3291 22.8088C32.8006 23.3294 32.2811 23.8573 31.7557 24.3808C31.1382 24.9965 30.3931 25.2657 29.5321 25.1408C29.1922 25.0932 28.8672 24.9474 28.4738 24.8285ZM40.3945 32.7329C40.3945 32.4385 40.3945 32.2184 40.3945 31.9983C40.3945 27.733 40.3945 23.4692 40.3945 19.2039C40.3945 18.0438 40.7507 17.6929 41.9263 17.6884C42.1326 17.6869 42.3389 17.6884 42.6774 17.6884C40.914 15.6301 39.2575 13.6967 37.5728 11.7292C35.8494 13.7191 34.1751 15.6509 32.4088 17.6899C32.8852 17.6899 33.197 17.6824 33.5072 17.6914C34.3132 17.7167 34.7258 18.1152 34.7718 18.9258C34.7896 19.2395 34.8 19.5578 34.7733 19.8701C34.7228 20.4561 34.7689 20.9602 35.4472 21.1729C35.6105 21.2235 35.747 21.3871 35.8777 21.5179C36.8365 22.4712 37.8028 23.4186 38.7424 24.3897C39.8111 25.4947 39.7918 26.9447 38.7142 28.0601C38.1858 28.6059 37.6485 29.1413 37.1067 29.6738C36.7772 29.998 36.7 30.3594 36.8811 30.7847C37.0696 31.2264 37.2536 31.6711 37.4303 32.1172C37.5831 32.5009 37.8592 32.7225 38.2704 32.7285C38.9517 32.7419 39.6345 32.7329 40.3945 32.7329Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M22.9758 42.3461C20.2521 42.3669 17.9781 40.151 17.9573 37.4562C17.9351 34.6112 20.1111 32.3447 22.8987 32.309C25.618 32.2748 27.9276 34.5294 27.9513 37.2405C27.9751 40.0707 25.7783 42.3253 22.9758 42.3461ZM22.9283 40.6522C24.7867 40.6581 26.2963 39.1575 26.2814 37.3164C26.2681 35.499 24.7585 34.0074 22.9417 34.0148C21.1145 34.0222 19.6227 35.5109 19.6183 37.3298C19.6168 39.1516 21.1056 40.6477 22.9283 40.6522Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1036_178",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "44",
                            height: "57",
                            fill: "white",
                            transform: "translate(0.954346 0.674805)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 39,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 32,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Educational Certificate Attestation"
        }, void 0, false),
        description: "Educational documents establish your professional identity and are essential when applying for jobs, universities, or licenses abroad.",
        link: "/services/Educational-Certificate-Attestation"
    },
    {
        id: "03",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "40",
            height: "40",
            viewBox: "0 0 40 40",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1036_236)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M0.848389 36.0426C0.848389 25.4554 0.848389 14.8671 0.848389 4.27888C0.873829 4.22495 0.912498 4.17305 0.923692 4.11606C1.1089 3.20428 1.56174 2.45328 2.25371 1.83559C2.85716 1.29728 3.5878 1.04084 4.35203 0.851562C13.3915 0.851562 22.4299 0.851562 31.4694 0.851562C31.5274 0.874968 31.5844 0.907531 31.6444 0.919743C33.646 1.32577 34.9659 2.92851 34.971 4.96781C34.974 5.95794 34.972 6.94808 34.971 7.93822C34.971 8.71262 34.6932 8.99144 33.9167 8.99144C32.2539 8.99246 30.5912 8.99144 28.9284 8.99144C28.793 8.99144 28.6577 8.99144 28.5101 8.99144C28.5101 11.1732 28.5101 13.3102 28.5101 15.4787C28.6831 15.4787 28.8327 15.4787 28.9823 15.4787C31.8001 15.4787 34.6179 15.4747 37.4356 15.4808C38.7646 15.4838 39.8423 16.5472 39.8433 17.8681C39.8484 24.4052 39.8484 30.9413 39.8423 37.4785C39.8413 38.778 38.7616 39.8475 37.456 39.8485C32.544 39.8546 27.6319 39.8546 22.7199 39.8475C21.4225 39.8455 20.3642 38.7637 20.3489 37.4602C20.3458 37.1864 20.3489 36.9127 20.3489 36.6095C20.1321 36.6095 19.9693 36.6095 19.8055 36.6095C13.8525 36.6095 7.89943 36.6064 1.94741 36.6156C1.46303 36.6145 1.0804 36.4945 0.848389 36.0426ZM20.3499 34.9609C20.3499 34.7798 20.3499 34.6302 20.3499 34.4796C20.3499 28.9702 20.3489 23.4609 20.3509 17.9525C20.3519 16.5309 21.4052 15.4828 22.8278 15.4787C24.0215 15.4757 25.2141 15.4777 26.4078 15.4777C26.5421 15.4777 26.6764 15.4777 26.8331 15.4777C26.8331 15.2752 26.8331 15.1236 26.8331 14.973C26.8301 12.0158 26.8179 9.05759 26.8291 6.10041C26.8341 4.86706 26.7538 3.60624 27.6187 2.50518C27.4294 2.49602 27.3063 2.48483 27.1832 2.48483C19.8462 2.48381 12.5092 2.4828 5.17222 2.48788C4.88221 2.48788 4.58404 2.50111 4.30522 2.57235C3.13395 2.86949 2.48064 3.81078 2.48064 5.1754C2.47962 14.9628 2.47962 24.7492 2.47962 34.5366C2.47962 34.6729 2.47962 34.8093 2.47962 34.963C8.44792 34.9609 14.3725 34.9609 20.3499 34.9609ZM38.2172 27.6952C38.2172 24.5487 38.2172 21.4012 38.2172 18.2548C38.2172 17.341 37.9841 17.1089 37.0673 17.1089C32.4229 17.1089 27.7785 17.1089 23.1351 17.11C22.9835 17.11 22.8298 17.111 22.6802 17.1313C22.2946 17.1842 22.0646 17.4102 22.0056 17.7948C21.9822 17.9444 21.9822 18.0981 21.9822 18.2497C21.9811 24.5304 21.9811 30.8121 21.9822 37.0928C21.9822 37.2567 21.9842 37.4246 22.0147 37.5853C22.0778 37.9171 22.2874 38.1257 22.6192 38.1867C22.7922 38.2183 22.9723 38.2193 23.1494 38.2193C27.5648 38.2213 31.9812 38.2213 36.3966 38.2203C36.764 38.2203 37.1334 38.2295 37.4987 38.1979C37.9047 38.1623 38.1408 37.9161 38.1948 37.5151C38.2172 37.3523 38.2161 37.1864 38.2161 37.0216C38.2172 33.9128 38.2172 30.804 38.2172 27.6952ZM28.499 7.30831C30.1322 7.30831 31.7207 7.30831 33.3133 7.30831C33.3133 6.39552 33.3581 5.50816 33.3021 4.6269C33.2258 3.41493 32.144 2.48483 30.9066 2.48788C29.6916 2.49094 28.5946 3.41391 28.5112 4.59536C28.4491 5.48781 28.499 6.38941 28.499 7.30831Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M14.6727 12.2121C17.2605 12.2121 19.8472 12.2121 22.435 12.2121C22.549 12.2121 22.664 12.207 22.7769 12.2151C23.2573 12.2497 23.6094 12.6029 23.6073 13.0404C23.6053 13.48 23.2542 13.8281 22.7729 13.8637C22.6976 13.8698 22.6202 13.8657 22.5449 13.8657C17.2808 13.8657 12.0177 13.8657 6.75362 13.8657C6.14203 13.8657 5.77366 13.6001 5.72685 13.132C5.67596 12.6161 6.03925 12.2233 6.60504 12.2151C7.42931 12.2039 8.25358 12.2121 9.07886 12.2121C10.9441 12.2121 12.8084 12.2121 14.6727 12.2121Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M14.6676 8.16522C17.3459 8.16522 20.0243 8.16318 22.7026 8.16623C23.3702 8.16725 23.8037 8.72287 23.5249 9.26831C23.415 9.48404 23.1392 9.63261 22.9112 9.76185C22.7932 9.82901 22.6131 9.79441 22.4615 9.79441C17.2574 9.79543 12.0523 9.79543 6.84823 9.79543C6.74647 9.79543 6.64471 9.79747 6.54396 9.78933C6.02193 9.7476 5.70443 9.41383 5.72682 8.93148C5.74717 8.48068 6.09316 8.16827 6.59484 8.16725C7.85159 8.16318 9.10835 8.16623 10.3651 8.16623C11.7989 8.16522 13.2337 8.16522 14.6676 8.16522Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.1948 26.0537C10.3692 26.0537 8.54258 26.0517 6.71698 26.0557C6.38321 26.0568 6.08606 25.9886 5.87847 25.7047C5.5335 25.2345 5.76552 24.5944 6.34352 24.4408C6.487 24.4021 6.64372 24.4021 6.79432 24.4021C10.4079 24.4001 14.0214 24.4001 17.636 24.4001C17.6991 24.4001 17.7632 24.398 17.8263 24.4011C18.3615 24.4194 18.735 24.7593 18.734 25.2284C18.733 25.6975 18.3605 26.0496 17.8242 26.0517C15.9477 26.0578 14.0713 26.0537 12.1948 26.0537Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2222 17.9128C10.3437 17.9128 8.46521 17.9107 6.58669 17.9148C6.2173 17.9158 5.95069 17.7611 5.79601 17.4304C5.66067 17.1414 5.67797 16.8341 5.89981 16.6143C6.05754 16.4586 6.29667 16.3436 6.51648 16.3029C6.81159 16.249 7.12298 16.2825 7.42724 16.2825C10.7905 16.2815 14.1547 16.2815 17.5179 16.2825C17.6695 16.2825 17.8232 16.2805 17.9738 16.2968C18.4297 16.3467 18.7594 16.7191 18.7319 17.1404C18.7044 17.5759 18.3584 17.9077 17.8954 17.9087C16.0932 17.9148 14.291 17.9107 12.4888 17.9117C12.4003 17.9128 12.3108 17.9128 12.2222 17.9128Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2487 20.353C14.0895 20.353 15.9294 20.352 17.7702 20.353C18.3472 20.353 18.7237 20.6674 18.7339 21.1498C18.7441 21.624 18.3645 21.9791 17.7957 21.9791C14.0763 21.9842 10.3579 21.9852 6.63857 21.9781C6.05141 21.9771 5.71255 21.6443 5.72578 21.1376C5.73799 20.6573 6.09212 20.353 6.65079 20.353C8.51709 20.352 10.3824 20.353 12.2487 20.353Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2121 30.0998C10.3336 30.0998 8.45505 30.0988 6.57654 30.1008C6.20715 30.1018 5.94257 29.941 5.79196 29.6083C5.65357 29.302 5.68104 28.9774 5.93036 28.7677C6.11658 28.611 6.39337 28.5021 6.63862 28.4838C7.19423 28.4421 7.75494 28.4696 8.31259 28.4696C11.4092 28.4696 14.5068 28.4696 17.6034 28.4696C18.334 28.4696 18.7441 28.7728 18.734 29.301C18.7238 29.822 18.3361 30.0998 17.6187 30.0998C15.8165 30.1008 14.0143 30.0998 12.2121 30.0998Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.1078 26.8576C28.3067 26.8576 26.5055 26.8586 24.7043 26.8576C23.8485 26.8566 23.5931 26.6022 23.5921 25.7474C23.591 23.7681 23.59 21.7899 23.5921 19.8106C23.5931 18.9803 23.8536 18.7198 24.684 18.7198C28.2995 18.7187 31.9141 18.7187 35.5297 18.7198C36.3366 18.7198 36.6022 18.9854 36.6032 19.7913C36.6053 21.795 36.6063 23.7997 36.6032 25.8034C36.6022 26.5839 36.3295 26.8546 35.549 26.8566C33.7356 26.8596 31.9222 26.8576 30.1078 26.8576ZM34.9578 20.3774C31.6984 20.3774 28.4705 20.3774 25.2528 20.3774C25.2528 22.0087 25.2528 23.6114 25.2528 25.207C28.5031 25.207 31.7218 25.207 34.9578 25.207C34.9578 23.5921 34.9578 21.9985 34.9578 20.3774Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.1775 33.3653C24.9363 33.3653 24.6951 33.3745 24.455 33.3643C23.9441 33.3419 23.5991 32.999 23.6022 32.5319C23.6063 32.079 23.9411 31.7341 24.4315 31.7188C24.9638 31.7015 25.497 31.7005 26.0292 31.7198C26.5187 31.7381 26.8474 32.0912 26.8433 32.5482C26.8392 33.002 26.5054 33.3378 26.0139 33.3633C25.7361 33.3765 25.4563 33.3643 25.1775 33.3653Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.0702 33.3653C29.829 33.3653 29.5878 33.3724 29.3477 33.3643C28.8297 33.3449 28.4827 33.0162 28.4776 32.5492C28.4725 32.0811 28.8165 31.73 29.3273 31.7167C29.8473 31.7025 30.3673 31.7015 30.8873 31.7178C31.3798 31.734 31.7136 32.076 31.7187 32.5288C31.7238 32.9979 31.3808 33.3409 30.869 33.3632C30.6034 33.3755 30.3368 33.3653 30.0702 33.3653Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M35.0259 31.7147C35.2793 31.7147 35.5337 31.7015 35.7871 31.7178C36.2746 31.7493 36.6012 32.0973 36.5941 32.5543C36.587 32.9939 36.2664 33.3399 35.7953 33.3592C35.2508 33.3816 34.7044 33.3806 34.16 33.3602C33.6725 33.3409 33.3449 32.9817 33.353 32.5258C33.3601 32.0872 33.6827 31.7503 34.1518 31.7198C34.4418 31.6995 34.7349 31.7147 35.0259 31.7147Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.1907 30.0977C24.9119 30.0977 24.632 30.1099 24.3542 30.0946C23.9339 30.0722 23.6246 29.7476 23.6042 29.3314C23.5839 28.9061 23.8495 28.5285 24.2698 28.5031C24.9007 28.4664 25.5367 28.4664 26.1676 28.501C26.5909 28.5244 26.8586 28.8949 26.8433 29.3202C26.828 29.7364 26.5207 30.059 26.1035 30.0956C26.0781 30.0977 26.0526 30.0977 26.0272 30.0977C25.7484 30.0977 25.4695 30.0977 25.1907 30.0977C25.1907 30.0987 25.1907 30.0987 25.1907 30.0977Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.0783 30.0987C29.7995 30.0987 29.5196 30.1089 29.2418 30.0967C28.8175 30.0763 28.5061 29.7609 28.4806 29.3457C28.4542 28.904 28.7279 28.5255 29.1696 28.501C29.7883 28.4664 30.4111 28.4664 31.0298 28.501C31.4724 28.5265 31.7441 28.905 31.7156 29.3477C31.6892 29.7639 31.3788 30.0773 30.9524 30.0967C30.6614 30.1089 30.3693 30.0987 30.0783 30.0987Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M34.9374 30.0978C34.6586 30.0978 34.3787 30.11 34.1009 30.0947C33.6816 30.0713 33.3723 29.7447 33.354 29.3285C33.3357 28.9031 33.6013 28.5276 34.0226 28.5032C34.6535 28.4666 35.2895 28.4666 35.9204 28.5022C36.3427 28.5266 36.6093 28.898 36.593 29.3244C36.5768 29.7406 36.2694 30.0713 35.8502 30.0937C35.5469 30.111 35.2417 30.0978 34.9374 30.0978Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.2538 34.9792C25.5204 34.9792 25.787 34.971 26.0526 34.9812C26.5034 34.9975 26.8209 35.3099 26.8423 35.7434C26.8636 36.1861 26.5889 36.5554 26.1432 36.5809C25.5367 36.6155 24.9261 36.6145 24.3206 36.5839C23.8718 36.5605 23.59 36.1993 23.6042 35.7597C23.6174 35.3292 23.938 35.0005 24.3807 34.9832C24.6707 34.97 24.9617 34.9792 25.2538 34.9792Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.1292 34.9792C30.3958 34.9792 30.6624 34.971 30.928 34.9812C31.3788 34.9975 31.6963 35.3099 31.7177 35.7434C31.7391 36.1861 31.4643 36.5554 31.0186 36.5809C30.4121 36.6155 29.8015 36.6145 29.196 36.5839C28.7473 36.5605 28.4654 36.1993 28.4796 35.7597C28.4929 35.3292 28.8134 35.0005 29.2561 34.9832C29.5451 34.97 29.8371 34.9792 30.1292 34.9792Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M35.0066 34.9802C35.2854 34.9802 35.5652 34.968 35.843 34.9833C36.2653 35.0057 36.5727 35.3282 36.592 35.7455C36.6113 36.1729 36.3478 36.5484 35.9275 36.5738C35.2966 36.6114 34.6606 36.6125 34.0297 36.5758C33.5921 36.5504 33.3234 36.1606 33.357 35.718C33.3886 35.3048 33.704 35.0036 34.1324 34.9792C34.1579 34.9782 34.1833 34.9782 34.2087 34.9782C34.4754 34.9782 34.741 34.9782 35.0076 34.9782C35.0066 34.9792 35.0066 34.9792 35.0066 34.9802Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1036_236",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "39",
                            height: "39",
                            fill: "white",
                            transform: "translate(0.848389 0.851562)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 75,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 73,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 53,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Personal Document Attestation"
        }, void 0, false),
        description: "Personal certificates carry deep emotional and legal significance. They represent life events, family relationships, identity details, and civil status. ",
        link: "/services/Personal-Document-Attestation"
    },
    {
        id: "04",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "40",
            height: "40",
            viewBox: "0 0 40 40",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1036_236)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M0.848389 36.0426C0.848389 25.4554 0.848389 14.8671 0.848389 4.27888C0.873829 4.22495 0.912498 4.17305 0.923692 4.11606C1.1089 3.20428 1.56174 2.45328 2.25371 1.83559C2.85716 1.29728 3.5878 1.04084 4.35203 0.851562C13.3915 0.851562 22.4299 0.851562 31.4694 0.851562C31.5274 0.874968 31.5844 0.907531 31.6444 0.919743C33.646 1.32577 34.9659 2.92851 34.971 4.96781C34.974 5.95794 34.972 6.94808 34.971 7.93822C34.971 8.71262 34.6932 8.99144 33.9167 8.99144C32.2539 8.99246 30.5912 8.99144 28.9284 8.99144C28.793 8.99144 28.6577 8.99144 28.5101 8.99144C28.5101 11.1732 28.5101 13.3102 28.5101 15.4787C28.6831 15.4787 28.8327 15.4787 28.9823 15.4787C31.8001 15.4787 34.6179 15.4747 37.4356 15.4808C38.7646 15.4838 39.8423 16.5472 39.8433 17.8681C39.8484 24.4052 39.8484 30.9413 39.8423 37.4785C39.8413 38.778 38.7616 39.8475 37.456 39.8485C32.544 39.8546 27.6319 39.8546 22.7199 39.8475C21.4225 39.8455 20.3642 38.7637 20.3489 37.4602C20.3458 37.1864 20.3489 36.9127 20.3489 36.6095C20.1321 36.6095 19.9693 36.6095 19.8055 36.6095C13.8525 36.6095 7.89943 36.6064 1.94741 36.6156C1.46303 36.6145 1.0804 36.4945 0.848389 36.0426ZM20.3499 34.9609C20.3499 34.7798 20.3499 34.6302 20.3499 34.4796C20.3499 28.9702 20.3489 23.4609 20.3509 17.9525C20.3519 16.5309 21.4052 15.4828 22.8278 15.4787C24.0215 15.4757 25.2141 15.4777 26.4078 15.4777C26.5421 15.4777 26.6764 15.4777 26.8331 15.4777C26.8331 15.2752 26.8331 15.1236 26.8331 14.973C26.8301 12.0158 26.8179 9.05759 26.8291 6.10041C26.8341 4.86706 26.7538 3.60624 27.6187 2.50518C27.4294 2.49602 27.3063 2.48483 27.1832 2.48483C19.8462 2.48381 12.5092 2.4828 5.17222 2.48788C4.88221 2.48788 4.58404 2.50111 4.30522 2.57235C3.13395 2.86949 2.48064 3.81078 2.48064 5.1754C2.47962 14.9628 2.47962 24.7492 2.47962 34.5366C2.47962 34.6729 2.47962 34.8093 2.47962 34.963C8.44792 34.9609 14.3725 34.9609 20.3499 34.9609ZM38.2172 27.6952C38.2172 24.5487 38.2172 21.4012 38.2172 18.2548C38.2172 17.341 37.9841 17.1089 37.0673 17.1089C32.4229 17.1089 27.7785 17.1089 23.1351 17.11C22.9835 17.11 22.8298 17.111 22.6802 17.1313C22.2946 17.1842 22.0646 17.4102 22.0056 17.7948C21.9822 17.9444 21.9822 18.0981 21.9822 18.2497C21.9811 24.5304 21.9811 30.8121 21.9822 37.0928C21.9822 37.2567 21.9842 37.4246 22.0147 37.5853C22.0778 37.9171 22.2874 38.1257 22.6192 38.1867C22.7922 38.2183 22.9723 38.2193 23.1494 38.2193C27.5648 38.2213 31.9812 38.2213 36.3966 38.2203C36.764 38.2203 37.1334 38.2295 37.4987 38.1979C37.9047 38.1623 38.1408 37.9161 38.1948 37.5151C38.2172 37.3523 38.2161 37.1864 38.2161 37.0216C38.2172 33.9128 38.2172 30.804 38.2172 27.6952ZM28.499 7.30831C30.1322 7.30831 31.7207 7.30831 33.3133 7.30831C33.3133 6.39552 33.3581 5.50816 33.3021 4.6269C33.2258 3.41493 32.144 2.48483 30.9066 2.48788C29.6916 2.49094 28.5946 3.41391 28.5112 4.59536C28.4491 5.48781 28.499 6.38941 28.499 7.30831Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 91,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M14.6727 12.2121C17.2605 12.2121 19.8472 12.2121 22.435 12.2121C22.549 12.2121 22.664 12.207 22.7769 12.2151C23.2573 12.2497 23.6094 12.6029 23.6073 13.0404C23.6053 13.48 23.2542 13.8281 22.7729 13.8637C22.6976 13.8698 22.6202 13.8657 22.5449 13.8657C17.2808 13.8657 12.0177 13.8657 6.75362 13.8657C6.14203 13.8657 5.77366 13.6001 5.72685 13.132C5.67596 12.6161 6.03925 12.2233 6.60504 12.2151C7.42931 12.2039 8.25358 12.2121 9.07886 12.2121C10.9441 12.2121 12.8084 12.2121 14.6727 12.2121Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 92,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M14.6676 8.16522C17.3459 8.16522 20.0243 8.16318 22.7026 8.16623C23.3702 8.16725 23.8037 8.72287 23.5249 9.26831C23.415 9.48404 23.1392 9.63261 22.9112 9.76185C22.7932 9.82901 22.6131 9.79441 22.4615 9.79441C17.2574 9.79543 12.0523 9.79543 6.84823 9.79543C6.74647 9.79543 6.64471 9.79747 6.54396 9.78933C6.02193 9.7476 5.70443 9.41383 5.72682 8.93148C5.74717 8.48068 6.09316 8.16827 6.59484 8.16725C7.85159 8.16318 9.10835 8.16623 10.3651 8.16623C11.7989 8.16522 13.2337 8.16522 14.6676 8.16522Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.1948 26.0537C10.3692 26.0537 8.54258 26.0517 6.71698 26.0557C6.38321 26.0568 6.08606 25.9886 5.87847 25.7047C5.5335 25.2345 5.76552 24.5944 6.34352 24.4408C6.487 24.4021 6.64372 24.4021 6.79432 24.4021C10.4079 24.4001 14.0214 24.4001 17.636 24.4001C17.6991 24.4001 17.7632 24.398 17.8263 24.4011C18.3615 24.4194 18.735 24.7593 18.734 25.2284C18.733 25.6975 18.3605 26.0496 17.8242 26.0517C15.9477 26.0578 14.0713 26.0537 12.1948 26.0537Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 94,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2222 17.9128C10.3437 17.9128 8.46521 17.9107 6.58669 17.9148C6.2173 17.9158 5.95069 17.7611 5.79601 17.4304C5.66067 17.1414 5.67797 16.8341 5.89981 16.6143C6.05754 16.4586 6.29667 16.3436 6.51648 16.3029C6.81159 16.249 7.12298 16.2825 7.42724 16.2825C10.7905 16.2815 14.1547 16.2815 17.5179 16.2825C17.6695 16.2825 17.8232 16.2805 17.9738 16.2968C18.4297 16.3467 18.7594 16.7191 18.7319 17.1404C18.7044 17.5759 18.3584 17.9077 17.8954 17.9087C16.0932 17.9148 14.291 17.9107 12.4888 17.9117C12.4003 17.9128 12.3108 17.9128 12.2222 17.9128Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2487 20.353C14.0895 20.353 15.9294 20.352 17.7702 20.353C18.3472 20.353 18.7237 20.6674 18.7339 21.1498C18.7441 21.624 18.3645 21.9791 17.7957 21.9791C14.0763 21.9842 10.3579 21.9852 6.63857 21.9781C6.05141 21.9771 5.71255 21.6443 5.72578 21.1376C5.73799 20.6573 6.09212 20.353 6.65079 20.353C8.51709 20.352 10.3824 20.353 12.2487 20.353Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M12.2121 30.0998C10.3336 30.0998 8.45505 30.0988 6.57654 30.1008C6.20715 30.1018 5.94257 29.941 5.79196 29.6083C5.65357 29.302 5.68104 28.9774 5.93036 28.7677C6.11658 28.611 6.39337 28.5021 6.63862 28.4838C7.19423 28.4421 7.75494 28.4696 8.31259 28.4696C11.4092 28.4696 14.5068 28.4696 17.6034 28.4696C18.334 28.4696 18.7441 28.7728 18.734 29.301C18.7238 29.822 18.3361 30.0998 17.6187 30.0998C15.8165 30.1008 14.0143 30.0998 12.2121 30.0998Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 97,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.1078 26.8576C28.3067 26.8576 26.5055 26.8586 24.7043 26.8576C23.8485 26.8566 23.5931 26.6022 23.5921 25.7474C23.591 23.7681 23.59 21.7899 23.5921 19.8106C23.5931 18.9803 23.8536 18.7198 24.684 18.7198C28.2995 18.7187 31.9141 18.7187 35.5297 18.7198C36.3366 18.7198 36.6022 18.9854 36.6032 19.7913C36.6053 21.795 36.6063 23.7997 36.6032 25.8034C36.6022 26.5839 36.3295 26.8546 35.549 26.8566C33.7356 26.8596 31.9222 26.8576 30.1078 26.8576ZM34.9578 20.3774C31.6984 20.3774 28.4705 20.3774 25.2528 20.3774C25.2528 22.0087 25.2528 23.6114 25.2528 25.207C28.5031 25.207 31.7218 25.207 34.9578 25.207C34.9578 23.5921 34.9578 21.9985 34.9578 20.3774Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.1775 33.3653C24.9363 33.3653 24.6951 33.3745 24.455 33.3643C23.9441 33.3419 23.5991 32.999 23.6022 32.5319C23.6063 32.079 23.9411 31.7341 24.4315 31.7188C24.9638 31.7015 25.497 31.7005 26.0292 31.7198C26.5187 31.7381 26.8474 32.0912 26.8433 32.5482C26.8392 33.002 26.5054 33.3378 26.0139 33.3633C25.7361 33.3765 25.4563 33.3643 25.1775 33.3653Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.0702 33.3653C29.829 33.3653 29.5878 33.3724 29.3477 33.3643C28.8297 33.3449 28.4827 33.0162 28.4776 32.5492C28.4725 32.0811 28.8165 31.73 29.3273 31.7167C29.8473 31.7025 30.3673 31.7015 30.8873 31.7178C31.3798 31.734 31.7136 32.076 31.7187 32.5288C31.7238 32.9979 31.3808 33.3409 30.869 33.3632C30.6034 33.3755 30.3368 33.3653 30.0702 33.3653Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M35.0259 31.7147C35.2793 31.7147 35.5337 31.7015 35.7871 31.7178C36.2746 31.7493 36.6012 32.0973 36.5941 32.5543C36.587 32.9939 36.2664 33.3399 35.7953 33.3592C35.2508 33.3816 34.7044 33.3806 34.16 33.3602C33.6725 33.3409 33.3449 32.9817 33.353 32.5258C33.3601 32.0872 33.6827 31.7503 34.1518 31.7198C34.4418 31.6995 34.7349 31.7147 35.0259 31.7147Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.1907 30.0977C24.9119 30.0977 24.632 30.1099 24.3542 30.0946C23.9339 30.0722 23.6246 29.7476 23.6042 29.3314C23.5839 28.9061 23.8495 28.5285 24.2698 28.5031C24.9007 28.4664 25.5367 28.4664 26.1676 28.501C26.5909 28.5244 26.8586 28.8949 26.8433 29.3202C26.828 29.7364 26.5207 30.059 26.1035 30.0956C26.0781 30.0977 26.0526 30.0977 26.0272 30.0977C25.7484 30.0977 25.4695 30.0977 25.1907 30.0977C25.1907 30.0987 25.1907 30.0987 25.1907 30.0977Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.0783 30.0987C29.7995 30.0987 29.5196 30.1089 29.2418 30.0967C28.8175 30.0763 28.5061 29.7609 28.4806 29.3457C28.4542 28.904 28.7279 28.5255 29.1696 28.501C29.7883 28.4664 30.4111 28.4664 31.0298 28.501C31.4724 28.5265 31.7441 28.905 31.7156 29.3477C31.6892 29.7639 31.3788 30.0773 30.9524 30.0967C30.6614 30.1089 30.3693 30.0987 30.0783 30.0987Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M34.9374 30.0978C34.6586 30.0978 34.3787 30.11 34.1009 30.0947C33.6816 30.0713 33.3723 29.7447 33.354 29.3285C33.3357 28.9031 33.6013 28.5276 34.0226 28.5032C34.6535 28.4666 35.2895 28.4666 35.9204 28.5022C36.3427 28.5266 36.6093 28.898 36.593 29.3244C36.5768 29.7406 36.2694 30.0713 35.8502 30.0937C35.5469 30.111 35.2417 30.0978 34.9374 30.0978Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 104,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M25.2538 34.9792C25.5204 34.9792 25.787 34.971 26.0526 34.9812C26.5034 34.9975 26.8209 35.3099 26.8423 35.7434C26.8636 36.1861 26.5889 36.5554 26.1432 36.5809C25.5367 36.6155 24.9261 36.6145 24.3206 36.5839C23.8718 36.5605 23.59 36.1993 23.6042 35.7597C23.6174 35.3292 23.938 35.0005 24.3807 34.9832C24.6707 34.97 24.9617 34.9792 25.2538 34.9792Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M30.1292 34.9792C30.3958 34.9792 30.6624 34.971 30.928 34.9812C31.3788 34.9975 31.6963 35.3099 31.7177 35.7434C31.7391 36.1861 31.4643 36.5554 31.0186 36.5809C30.4121 36.6155 29.8015 36.6145 29.196 36.5839C28.7473 36.5605 28.4654 36.1993 28.4796 35.7597C28.4929 35.3292 28.8134 35.0005 29.2561 34.9832C29.5451 34.97 29.8371 34.9792 30.1292 34.9792Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M35.0066 34.9802C35.2854 34.9802 35.5652 34.968 35.843 34.9833C36.2653 35.0057 36.5727 35.3282 36.592 35.7455C36.6113 36.1729 36.3478 36.5484 35.9275 36.5738C35.2966 36.6114 34.6606 36.6125 34.0297 36.5758C33.5921 36.5504 33.3234 36.1606 33.357 35.718C33.3886 35.3048 33.704 35.0036 34.1324 34.9792C34.1579 34.9782 34.1833 34.9782 34.2087 34.9782C34.4754 34.9782 34.741 34.9782 35.0076 34.9782C35.0066 34.9792 35.0066 34.9792 35.0066 34.9802Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 90,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1036_236",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "39",
                            height: "39",
                            fill: "white",
                            transform: "translate(0.848389 0.851562)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 109,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 89,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Commercial Document Attestation"
        }, void 0, false),
        description: "Commercial documents are essential for business, showing legal identity, finances, ownership, contracts, and international operations."
    },
    {
        id: "05",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "53",
            height: "54",
            viewBox: "0 0 53 54",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1041_2)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M42.5235 30.6081C42.868 30.2543 43.1887 29.9005 43.5332 29.5703C43.9727 29.1457 44.4715 29.134 44.8991 29.5585C47.4886 32.1177 50.0661 34.6769 52.6437 37.2361C53.1544 37.755 53.1069 38.1796 52.513 38.8046C49.5435 41.9181 46.5858 45.0316 43.6163 48.1451C42.1197 49.7254 40.6112 51.2939 39.1145 52.8743C38.3781 53.6409 38.0098 53.6526 37.2734 52.9215C34.8384 50.5038 32.4034 48.0861 29.9684 45.6684C29.03 44.7368 29.03 44.5716 29.8615 43.6282C29.2438 43.0267 28.638 42.4252 28.056 41.8474C27.6403 42.0832 27.1414 42.4606 26.5831 42.6375C24.9321 43.1446 23.2573 41.9299 23.1741 40.2198C23.1504 39.7481 23.1979 39.2646 23.1504 38.7928C23.1385 38.6277 22.9722 38.4036 22.8297 38.3447C21.5231 37.8729 20.656 37.0002 20.1808 35.7029C20.1333 35.5614 19.9433 35.3963 19.7889 35.3727C18.019 35.0661 16.855 34.0754 16.273 32.389C16.2254 32.2356 16.0473 32.0705 15.881 32.0234C13.8498 31.3275 12.7927 29.8887 12.7808 27.7541C12.7808 27.6126 12.7808 27.4593 12.7808 27.3178C12.7808 25.2539 12.757 25.2067 10.9753 23.7797C10.8209 23.9802 10.6665 24.2279 10.4765 24.4166C9.91819 24.9826 9.46682 24.9826 8.90855 24.4283C7.55445 23.0957 6.21222 21.7512 4.85812 20.4186C3.409 18.9797 1.94799 17.5291 0.498867 16.0903C-0.178184 15.4181 -0.166306 15.0171 0.510745 14.3803C5.2501 9.87516 10.0013 5.40543 14.7407 0.935689C15.4177 0.29884 15.7741 0.310634 16.4274 0.959276C19.0881 3.60102 21.7488 6.23097 24.4094 8.87272C25.0509 9.50957 25.0509 9.92234 24.4213 10.5592C24.1719 10.8069 23.9224 11.0427 23.6255 11.3376C24.6114 12.1867 25.3122 13.2363 26.6663 13.6491C29.4101 14.4864 31.6194 16.1611 33.4012 18.4019C33.5912 18.6495 33.8763 18.85 34.1732 18.9797C38.6275 20.9846 41.1694 24.3694 41.7514 29.1929C41.8108 29.7708 41.9177 30.2661 42.5235 30.6081ZM9.64499 22.5414C13.9805 18.2486 18.316 13.9439 22.604 9.69826C20.2759 7.38673 17.9003 5.03983 15.5009 2.65754C11.0941 6.80885 6.65171 10.9955 2.23307 15.1587C4.73934 17.6471 7.22186 20.1237 9.64499 22.5414ZM33.1874 29.7708C33.9713 29.7708 34.684 29.7708 35.4086 29.7708C35.6461 29.7708 35.8956 29.7708 36.1331 29.7708C36.7745 29.7944 37.1903 30.1482 37.1784 30.6671C37.1665 31.1742 36.7864 31.5162 36.1569 31.528C35.0285 31.5398 33.9 31.5398 32.7716 31.528C31.667 31.528 31.4294 31.2922 31.4294 30.2072C31.4294 29.0396 31.4294 27.8603 31.4294 26.6927C30.4791 26.6101 29.5764 26.5394 28.6618 26.4686C28.6499 26.5512 28.638 26.6337 28.638 26.7281C28.638 30.9384 28.638 35.1486 28.638 39.3589C28.638 39.5004 28.6499 39.6773 28.7449 39.7599C29.5527 40.5854 30.3841 41.3992 31.2393 42.2365C34.6008 38.781 37.9148 35.3491 41.312 31.8465C40.1954 31.2214 40.0648 30.2072 39.9697 29.1104C39.5659 24.4519 35.5392 20.3124 30.8474 19.9114C28.3055 19.6874 25.7398 19.8171 23.186 19.7935C23.1622 19.7935 23.1385 19.8289 23.091 19.8643C23.1029 19.9232 23.1147 19.994 23.1385 20.0648C23.9581 22.5414 25.7635 23.9448 28.2342 24.4873C29.4695 24.7586 30.7642 24.7704 32.0352 24.8175C32.9023 24.8529 33.1992 25.077 33.2111 25.9497C33.2111 26.5748 33.2111 27.1998 33.2111 27.8249C33.1874 28.4617 33.1874 29.0868 33.1874 29.7708ZM23.1622 36.5639C23.1622 35.644 23.1504 34.842 23.1622 34.0283C23.1741 33.3796 23.5186 33.0022 24.0769 33.0258C24.6114 33.0376 24.9321 33.4032 24.9321 34.0283C24.944 35.2194 24.9321 36.4223 24.9321 37.6135C24.9321 38.3683 24.9321 39.1231 24.9321 39.8778C24.9321 40.5737 25.3003 40.9982 25.8823 40.9864C26.4644 40.9746 26.8088 40.5619 26.8207 39.8543C26.8207 39.7953 26.8207 39.7481 26.8207 39.6891C26.8207 35.2902 26.8088 30.903 26.8326 26.504C26.8326 26.0794 26.69 25.9143 26.3099 25.761C23.3879 24.5699 21.6537 22.4117 21.0717 19.3453C20.8935 18.4255 21.2499 18.0363 22.1882 18.0245C24.6826 18.0245 27.1889 18.0245 29.6833 18.0245C29.9684 18.0245 30.2535 18.0245 30.6217 18.0245C29.0419 16.5621 27.2958 15.6186 25.3359 15.0289C24.9202 14.8992 24.5045 14.6515 24.1719 14.3567C23.5423 13.8024 22.9722 13.1773 22.4258 12.6348C19.0524 15.9724 15.7384 19.2628 12.3651 22.6004C12.9233 23.1429 13.4935 23.7207 14.0874 24.2632C14.42 24.5699 14.5625 24.9355 14.5625 25.3836C14.5506 26.3035 14.5388 27.2234 14.5863 28.1433C14.6219 29.075 15.2633 29.8652 16.1304 30.1246C16.1304 29.9359 16.1304 29.759 16.1304 29.5821C16.1304 28.6976 16.1185 27.8131 16.1423 26.9286C16.1542 26.3861 16.5105 26.0441 16.9975 26.0323C17.4964 26.0205 17.8527 26.3625 17.9121 26.8814C17.924 27.0229 17.924 27.1762 17.924 27.3178C17.924 28.6622 17.9121 30.0067 17.9359 31.3393C17.9596 32.4833 18.8267 33.4032 20.0146 33.5211C20.0146 33.3206 20.0146 33.1202 20.0146 32.9315C20.0146 32.1649 20.0027 31.3865 20.0264 30.6199C20.0383 30.101 20.3828 29.7826 20.8579 29.759C21.333 29.7354 21.6894 30.0421 21.7725 30.5492C21.7963 30.7261 21.7963 30.9148 21.7963 31.1035C21.7963 32.2592 21.7844 33.415 21.8081 34.5826C21.8319 35.4789 22.2833 36.1039 23.1622 36.5639ZM38.2118 51.2468C42.4285 46.8242 46.6333 42.4016 50.7432 38.0852C48.522 35.868 46.3364 33.6862 44.1271 31.4809C39.9222 35.8209 35.6699 40.1963 31.4531 44.5363C33.7337 46.8006 35.9549 49.006 38.2118 51.2468Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 127,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M32.6647 10.2292C32.7122 4.75701 37.1071 0.428794 42.5948 0.475968C48.0231 0.523142 52.3348 4.93391 52.2873 10.4061C52.2398 15.6896 47.7499 20.0296 42.3929 19.9824C37.0358 19.9352 32.6172 15.5127 32.6647 10.2292ZM34.4464 10.2764C34.5296 14.7461 38.1643 18.2959 42.5592 18.2134C47.1085 18.1308 50.6006 14.5102 50.5175 9.95794C50.4343 5.62973 46.7165 2.16244 42.2503 2.24499C37.9505 2.32755 34.3633 6.00712 34.4464 10.2764Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 128,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M41.7396 11.8095C42.3097 11.0429 42.8442 10.3471 43.3669 9.6395C43.8776 8.96727 44.3765 8.28324 44.8873 7.61101C45.3624 6.96237 45.8494 6.82085 46.3245 7.18645C46.7759 7.52846 46.764 8.05917 46.3008 8.68422C45.5287 9.72205 44.7566 10.7481 43.9845 11.7859C43.5332 12.3874 43.0818 13.0006 42.6304 13.6021C42.1197 14.2743 41.5376 14.2979 40.9794 13.6611C40.1835 12.7412 39.3877 11.8213 38.6038 10.9014C38.1762 10.4061 38.1762 9.88716 38.5919 9.54515C39.0076 9.19134 39.5065 9.2621 39.946 9.75743C40.528 10.4061 41.0982 11.0783 41.7396 11.8095Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 129,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 126,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1041_2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "53",
                            height: "53",
                            fill: "white",
                            transform: "translate(0 0.463867)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 133,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 131,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 125,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "MOFA Attestation (UAE)"
        }, void 0, false),
        description: "MOFA attestation is the final and most essential stage for any document intended for use within the UAE. ",
        link: "/services/MOFA-Attestation"
    },
    {
        id: "06",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "52",
            height: "52",
            viewBox: "0 0 52 52",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19.9553 9.7129C26.2708 9.72125 31.3833 14.8413 31.3666 21.1557C31.3499 27.4785 26.2373 32.5735 19.9135 32.5568C13.6064 32.5401 8.51055 27.4117 8.53561 21.0889C8.55232 14.7995 13.6649 9.70455 19.9553 9.7129ZM9.97247 21.8573C10.173 24.2879 11.1086 26.3426 12.7626 28.0883C13.2388 27.7709 13.6732 27.4535 14.141 27.1862C14.425 27.0275 14.5002 26.8855 14.4 26.5514C14.1995 25.8749 14.0324 25.19 13.9155 24.4967C13.7651 23.6281 13.6899 22.7427 13.573 21.8573C12.37 21.8573 11.1921 21.8573 9.97247 21.8573ZM27.1479 28.0799C28.7936 26.3426 29.7292 24.2879 29.9297 21.8657C28.6934 21.8657 27.5071 21.8657 26.4462 21.8657C26.112 23.5278 25.7862 25.1399 25.4688 26.7519C25.4521 26.8521 25.5189 27.0108 25.5941 27.0693C26.0953 27.4117 26.6049 27.7291 27.1479 28.0799ZM27.1395 14.1815C26.63 14.5156 26.1789 14.8413 25.6943 15.1169C25.4187 15.2673 25.427 15.4343 25.4938 15.6849C25.686 16.4199 25.8781 17.1466 26.0118 17.8899C26.1538 18.7168 26.2206 19.5521 26.3125 20.3706C27.5238 20.3706 28.7101 20.3706 29.9214 20.3706C29.7125 17.9735 28.7936 15.9271 27.1395 14.1815ZM12.7543 14.1898C11.1002 15.9271 10.173 17.9735 9.97247 20.379C11.2255 20.379 12.4118 20.379 13.456 20.379C13.7902 18.7335 14.1076 17.1633 14.4167 15.5763C14.4418 15.4594 14.3916 15.2673 14.3081 15.2088C13.8152 14.858 13.2973 14.5406 12.7543 14.1898ZM14.9346 21.849C15.1936 23.3858 15.4359 24.8475 15.6781 26.2507C16.8644 26.0252 17.9169 25.8331 18.9695 25.6159C19.0781 25.5909 19.2201 25.3737 19.2285 25.2401C19.2536 24.5635 19.2368 23.887 19.2452 23.2188C19.2452 22.7678 19.2452 22.3167 19.2452 21.8573C17.8167 21.849 16.4634 21.849 14.9346 21.849ZM19.1951 20.3873C19.1951 19.1345 19.1951 17.9066 19.1951 16.754C18.0255 16.4951 16.9145 16.2445 15.6865 15.9772C15.4442 17.4222 15.202 18.8839 14.9513 20.3957C16.455 20.3873 17.8167 20.3873 19.1951 20.3873ZM20.657 21.8573C20.657 22.7761 20.657 23.6364 20.657 24.4884C20.657 25.5324 20.657 25.5157 21.6427 25.7078C22.4614 25.8749 23.2717 26.0837 24.2074 26.3008C24.4496 24.8308 24.7002 23.3691 24.9508 21.849C23.4555 21.8573 22.0938 21.8573 20.657 21.8573ZM20.6904 20.3706C22.0938 20.3706 23.4639 20.3706 24.859 20.3706C24.7671 18.8338 24.5749 17.3637 24.1071 15.9939C22.9459 16.2529 21.8349 16.4951 20.6904 16.7457C20.6904 17.915 20.6904 19.1177 20.6904 20.3706ZM19.2201 11.375C17.7081 12.0265 16.9646 13.2293 16.2796 14.6575C17.2988 14.8831 18.2344 15.0919 19.2201 15.309C19.2201 13.9392 19.2201 12.7114 19.2201 11.375ZM19.2118 30.878C19.2118 29.5583 19.2118 28.3305 19.2118 26.9607C18.2177 27.1862 17.2821 27.395 16.2712 27.6205C16.9813 29.0321 17.6997 30.2599 19.2118 30.878ZM23.6226 14.6408C22.9209 13.2293 22.1941 12.0015 20.6904 11.3834C20.6904 12.7114 20.6904 13.9476 20.6904 15.309C21.6845 15.0835 22.6201 14.8747 23.6226 14.6408ZM20.6821 30.8947C22.1857 30.2265 22.9376 29.0488 23.6142 27.6122C22.6034 27.3867 21.6678 27.1862 20.6821 26.969C20.6821 28.3388 20.6821 29.5583 20.6821 30.8947ZM16.2044 11.9179C16.1793 11.8845 16.1626 11.8595 16.1376 11.8261C15.3941 12.252 14.6422 12.6864 13.7985 13.1708C14.2747 13.4799 14.6255 13.7137 14.9931 13.9559C15.4108 13.246 15.8034 12.5861 16.2044 11.9179ZM23.7479 11.8261C23.7312 11.8595 23.7145 11.8845 23.6978 11.9179C24.0988 12.5861 24.4914 13.246 24.9174 13.9559C25.285 13.7054 25.6442 13.4715 26.112 13.1625C25.2432 12.6697 24.4914 12.252 23.7479 11.8261ZM24.9091 28.3054C24.4997 29.007 24.1238 29.6418 23.7479 30.285C23.773 30.3267 23.8064 30.3685 23.8314 30.4102C24.5582 29.9843 25.2934 29.5667 26.1037 29.0989C25.6275 28.7815 25.2766 28.5477 24.9091 28.3054ZM13.7902 29.0989C14.6255 29.575 15.3523 29.9926 16.0707 30.4019C16.0958 30.3601 16.1209 30.3267 16.1543 30.285C15.77 29.6335 15.3857 28.982 14.9848 28.3054C14.6255 28.5477 14.2747 28.7815 13.7902 29.0989Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 148,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M35.8609 30.8946C35.3597 30.3349 34.8167 29.8589 34.424 29.2825C32.8869 27.019 32.4275 24.5634 33.5218 21.9909C34.4408 19.8359 36.2702 18.9422 38.5174 18.7919C39.5533 18.7251 40.5725 18.8503 41.5415 19.2596C43.7051 20.17 44.7494 21.8906 44.8914 24.1458C45.0584 26.735 44.1897 28.9484 42.1764 30.6607C42.1179 30.7108 42.0678 30.7776 41.9926 30.8612C43.6634 31.2955 45.2924 31.688 46.913 32.1558C47.7484 32.398 48.5838 32.6987 49.369 33.0662C50.8309 33.7427 51.6329 34.9538 51.6914 36.5408C51.7916 39.4892 51.8083 42.446 51.8501 45.3944C51.8584 46.0542 51.8167 46.7141 51.7916 47.3656C51.6997 49.6876 50.0791 51.2662 47.7484 51.2662C44.1896 51.2745 40.6226 51.2662 37.0639 51.2662C34.7833 51.2662 32.5027 51.2662 30.2304 51.2662C27.8162 51.2578 26.1705 49.746 26.1204 47.3405C26.0535 44.033 26.0869 40.7254 26.1037 37.4178C26.1037 36.9 26.2039 36.3738 26.2958 35.8643C26.5882 34.3441 27.5656 33.3585 28.9523 32.8657C30.5061 32.3061 32.1017 31.8969 33.6889 31.4375C34.399 31.2287 35.1258 31.0783 35.8609 30.8946ZM37.0722 32.0639C35.9027 32.3479 34.825 32.5651 33.7725 32.8741C32.2354 33.3168 30.7066 33.7762 29.2029 34.3191C28.2589 34.6615 27.7494 35.4383 27.624 36.4406C27.5739 36.8248 27.5071 37.209 27.5071 37.5932C27.4987 40.7839 27.482 43.9661 27.5238 47.1568C27.5489 49.0862 28.8688 50.1135 30.8486 49.7794C30.8486 49.6124 30.8486 49.4286 30.8486 49.2449C30.8486 46.5637 30.8486 43.8826 30.8486 41.1931C30.8486 41.0094 30.8403 40.8173 30.8987 40.6419C30.999 40.2911 31.258 40.1073 31.6255 40.1407C31.9847 40.1741 32.2103 40.3913 32.2604 40.7588C32.2771 40.9091 32.2688 41.0595 32.2688 41.2098C32.2688 43.891 32.2688 46.5721 32.2688 49.2616C32.2688 49.437 32.2688 49.6207 32.2688 49.8128C36.7548 49.8128 41.1656 49.8128 45.6265 49.8128C45.6265 49.604 45.6265 49.4203 45.6265 49.2365C45.6265 46.5721 45.6265 43.9077 45.6265 41.2349C45.6265 41.0845 45.6098 40.9258 45.6349 40.7839C45.6933 40.3746 45.9356 40.1407 46.3449 40.1407C46.7376 40.1407 46.9631 40.3829 47.0299 40.7588C47.055 40.9091 47.0383 41.0595 47.0383 41.2098C47.0383 43.891 47.0383 46.5721 47.0383 49.2616C47.0383 49.437 47.0383 49.6207 47.0383 49.8379C47.339 49.8379 47.5729 49.8379 47.8068 49.8379C49.2771 49.8128 50.3381 48.8523 50.3548 47.3906C50.3965 44.0497 50.3715 40.7087 50.3715 37.3677C50.3715 35.597 49.5695 34.4193 47.8403 33.9181C47.6648 33.868 47.4894 33.7845 47.314 33.7427C45.7852 33.3335 44.2565 32.9242 42.7194 32.5233C42.1096 32.3646 41.4997 32.2226 40.8231 32.0556C40.8565 32.3395 40.8732 32.54 40.9066 32.7405C41.3995 36.3153 41.9007 39.8901 42.3769 43.465C42.4103 43.749 42.3184 44.1081 42.1597 44.3503C41.341 45.5531 40.4889 46.7224 39.6452 47.9001C39.1857 48.5433 38.7012 48.5433 38.2417 47.9001C37.4231 46.7642 36.6295 45.6116 35.7941 44.484C35.5184 44.1165 35.4349 43.749 35.4933 43.3063C35.8526 40.7839 36.2034 38.2614 36.5543 35.7473C36.7213 34.5529 36.8884 33.3585 37.0722 32.0639ZM43.513 25.1731C43.5213 22.5588 42.4855 20.9552 40.6226 20.4457C39.9543 20.2619 39.2191 20.1867 38.5258 20.2201C36.4373 20.3204 35.0255 21.3728 34.5744 23.227C33.9813 25.6576 34.6412 27.7791 36.4958 29.4579C37.9326 30.7609 39.854 30.7526 41.341 29.5081C42.8196 28.2802 43.4545 26.6432 43.513 25.1731ZM38.5592 31.8634C38.5174 32.0639 38.4756 32.2393 38.4506 32.4231C37.9494 36.023 37.4481 39.6312 36.9469 43.2311C36.9302 43.3731 36.9051 43.5652 36.972 43.6654C37.6069 44.5842 38.2668 45.4946 38.9518 46.4468C39.57 45.5782 40.1715 44.7847 40.7145 43.9578C40.8732 43.7239 40.9567 43.3648 40.915 43.0808C40.5808 40.4915 40.2132 37.9106 39.8457 35.3214C39.6869 34.1771 39.5199 33.0244 39.3528 31.8634C39.0688 31.8634 38.8265 31.8634 38.5592 31.8634Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 149,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M33.3046 6.0294C34.1066 6.0294 34.8417 6.02104 35.5852 6.0294C36.9553 6.05445 38.1164 6.5556 39.0103 7.61636C39.4447 8.13421 39.6786 8.73559 39.6702 9.42884C39.6619 11.7091 39.6702 13.9893 39.6702 16.2611C39.6702 16.8291 39.4363 17.1298 38.9936 17.1465C38.5341 17.1632 38.2584 16.8375 38.2584 16.2611C38.2501 14.1647 38.2584 12.0766 38.2584 9.9801C38.2584 8.58524 37.5818 7.7667 36.1951 7.50778C35.9444 7.45766 35.6938 7.44096 35.4432 7.44096C25.1263 7.44096 14.8093 7.44096 4.50071 7.44096C3.03044 7.44096 2.28695 8.19268 2.28695 9.65436C2.28695 22.3167 2.28695 34.9706 2.28695 47.6329C2.28695 49.1029 3.03044 49.8463 4.49236 49.8463C10.7911 49.8463 17.0899 49.8463 23.3803 49.8463C23.5474 49.8463 23.7145 49.8379 23.8899 49.8546C24.2825 49.8797 24.5248 50.1052 24.5582 50.4894C24.6 50.8987 24.3577 51.1576 23.9651 51.2412C23.8064 51.2746 23.6309 51.2662 23.4639 51.2662C17.1484 51.2662 10.8329 51.2662 4.52577 51.2662C2.22012 51.2662 0.850098 49.8964 0.850098 47.6078C0.850098 34.9622 0.850098 22.325 0.850098 9.67941C0.850098 7.56625 1.96115 6.38855 4.04961 6.01269C6.32184 5.60342 8.56902 5.05216 10.8162 4.55102C17.0815 3.15616 23.3553 1.77801 29.6206 0.349738C31.7592 -0.134704 33.1543 1.7446 33.2712 3.20627C33.3297 3.94129 33.2963 4.69301 33.3046 5.43637C33.3046 5.61178 33.3046 5.79553 33.3046 6.0294ZM31.8511 6.01269C31.8511 5.06051 31.9263 4.14175 31.8344 3.24803C31.7174 2.08705 30.8319 1.54414 29.7125 1.79471C24.1739 3.02252 18.6354 4.25868 13.0968 5.49484C12.4452 5.63683 11.8019 5.78718 11.1503 5.92917C11.1587 5.95423 11.1587 5.97928 11.1671 6.00434C18.0422 6.01269 24.9174 6.01269 31.8511 6.01269Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 150,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16.3966 41.7779C14.0826 41.7779 11.7769 41.7779 9.46289 41.7695C9.25405 41.7695 8.97837 41.7612 8.84471 41.6359C8.67764 41.4939 8.53562 41.2099 8.56068 41.0011C8.58574 40.8007 8.78624 40.5668 8.97837 40.4415C9.12874 40.3413 9.36265 40.358 9.56314 40.358C14.1327 40.358 18.7022 40.358 23.2717 40.358C23.3219 40.358 23.372 40.358 23.4221 40.358C23.9735 40.3747 24.2825 40.6336 24.2825 41.0763C24.2825 41.519 23.9818 41.7779 23.4221 41.7779C21.0914 41.7779 18.744 41.7779 16.3966 41.7779Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 151,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16.4049 36.6496C18.6604 36.6496 20.9243 36.6496 23.1798 36.6496C23.3803 36.6496 23.6309 36.6078 23.7729 36.6997C23.9818 36.8417 24.2491 37.1006 24.2491 37.3094C24.2491 37.5433 24.0152 37.8189 23.8064 37.9943C23.681 38.1029 23.4221 38.0612 23.2216 38.0612C18.6855 38.0612 14.1493 38.0612 9.61323 38.0612C9.44616 38.0612 9.27073 38.0695 9.112 38.0361C8.72773 37.9609 8.52724 37.7187 8.53559 37.3262C8.5523 36.9586 8.75279 36.7331 9.12036 36.6747C9.30414 36.6496 9.48792 36.6496 9.67171 36.6496C11.9189 36.6496 14.1577 36.6496 16.4049 36.6496Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 152,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 147,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Apostille Services"
        }, void 0, false),
        description: "The Apostille process is a simplified method of international document legalisation, accepted by all member countries of the Hague Convention. ",
        link: "/services/Apostille-Services"
    },
    {
        id: "07",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "48",
            height: "47",
            viewBox: "0 0 48 47",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M0.761108 31.3608C0.941108 30.4508 1.13111 29.5408 1.29111 28.6308C2.03111 24.4708 2.76111 20.3108 3.49111 16.1408C3.61111 15.4508 3.90111 15.2608 4.61111 15.3808C5.63111 15.5608 6.65111 15.7408 7.68111 15.9208C8.42111 16.0508 8.60111 16.3208 8.47111 17.0808C8.44111 17.2608 8.42111 17.4408 8.38111 17.6708C9.44111 17.8408 10.4711 18.2208 11.6111 17.8008C11.6111 17.6508 11.6111 17.4808 11.6111 17.3008C11.6111 13.9908 11.6111 10.6708 11.6111 7.36078C11.6111 5.43078 12.8111 4.24078 14.7411 4.24078C16.1911 4.24078 17.6311 4.24078 19.0811 4.24078C19.2311 4.24078 19.3711 4.24078 19.5611 4.24078C19.5611 3.75078 19.5611 3.30078 19.5611 2.85078C19.5711 1.56078 20.4911 0.630781 21.7911 0.620781C23.2111 0.610781 24.6211 0.610781 26.0411 0.620781C27.3011 0.630781 28.2211 1.56078 28.2411 2.82078C28.2511 3.27078 28.2411 3.72078 28.2411 4.23078C28.4311 4.23078 28.5911 4.23078 28.7511 4.23078C30.2311 4.23078 31.7011 4.23078 33.1811 4.23078C34.9611 4.24078 36.1911 5.46078 36.2011 7.24078C36.2111 10.5808 36.2011 13.9308 36.2011 17.2708C36.2011 17.4508 36.2011 17.6308 36.2011 17.7808C37.3111 18.1908 38.3411 17.8308 39.4411 17.6608C39.3911 17.3808 39.3411 17.1208 39.3011 16.8608C39.2311 16.3808 39.4211 16.0508 39.9011 15.9608C41.0511 15.7408 42.2111 15.5308 43.3711 15.3508C43.9511 15.2608 44.2111 15.4908 44.3211 16.1108C44.6911 18.2008 45.0611 20.2908 45.4211 22.3808C45.9511 25.3708 46.4711 28.3608 47.0011 31.3608C47.1211 32.0508 46.9411 32.3308 46.2311 32.4608C45.1511 32.6608 44.0711 32.8508 42.9911 33.0408C42.4211 33.1408 42.2211 32.9608 41.9611 32.1208C41.5811 32.0708 41.3811 32.2608 41.1711 32.5908C40.5911 33.4608 39.9311 34.2808 39.3111 35.1208C39.2011 35.2708 39.0611 35.4408 39.0511 35.6008C38.8911 37.4608 37.6511 38.5308 35.7711 38.4008C35.7011 38.3908 35.6211 38.3908 35.4811 38.3808C35.4111 39.2808 35.0811 40.0708 34.3511 40.6408C33.6311 41.2008 32.8111 41.3508 31.8811 41.1808C31.8111 42.1108 31.4811 42.9008 30.7411 43.4608C30.0211 44.0108 29.2011 44.1808 28.2911 43.9908C28.2511 44.2008 28.2311 44.3908 28.1911 44.5708C27.9511 45.7108 27.2511 46.4208 26.1611 46.7808C26.0511 46.8208 25.9311 46.8508 25.8211 46.8908C25.5211 46.8908 25.2211 46.8908 24.9211 46.8908C24.5411 46.7308 24.1611 46.5508 23.7711 46.4108C23.5911 46.3508 23.3711 46.3008 23.2011 46.3508C21.5511 46.8608 19.9811 46.0208 19.4911 44.3508C19.4711 44.2708 19.4211 44.1908 19.3811 44.1108C18.4911 44.6408 17.5711 44.7308 16.6411 44.3308C15.7111 43.9308 15.1911 43.1608 14.9611 42.1808C13.7911 42.8308 12.6511 42.8608 11.6211 42.0508C10.3411 41.0408 10.2011 39.7308 10.8411 38.3008C9.53111 37.7908 8.83111 36.9208 8.76111 35.5608C8.75111 35.4108 8.61111 35.2608 8.50111 35.1208C7.88111 34.2808 7.22111 33.4608 6.64111 32.5908C6.42111 32.2608 6.23111 32.0808 5.85111 32.1208C5.60111 32.9508 5.39111 33.1408 4.82111 33.0408C3.77111 32.8608 2.71111 32.6908 1.67111 32.4708C1.35111 32.4008 1.06111 32.1608 0.761108 31.9908C0.761108 31.7808 0.761108 31.5708 0.761108 31.3608ZM24.3511 25.0408C23.5311 25.2108 22.7511 25.3608 21.9711 25.5408C21.8211 25.5808 21.6511 25.7008 21.5611 25.8308C21.1811 26.3708 20.8411 26.9408 20.4511 27.4808C19.5611 28.7208 18.3311 29.2608 16.8311 29.0008C14.4911 28.6008 13.9211 26.5808 15.0911 25.0808C15.9211 24.0108 16.6211 22.8508 17.3411 21.7008C17.8811 20.8408 18.6011 20.2308 19.5511 19.8708C20.3611 19.5608 21.1411 19.2008 22.0111 18.8208C20.9911 18.2908 20.0111 18.0608 18.9811 18.2108C16.7511 18.5308 14.5211 18.8708 12.2911 19.2308C11.1411 19.4208 10.0011 19.5808 8.86111 19.2508C8.63111 19.1908 8.39111 19.1708 8.12111 19.1308C7.43111 22.9808 6.75111 26.7908 6.08111 30.6308C6.23111 30.6708 6.34111 30.7208 6.45111 30.7208C7.14111 30.7508 7.56111 31.0608 7.82111 31.7308C8.13111 32.5308 8.64111 33.2208 9.22111 33.7908C10.4011 32.8008 11.5211 31.7908 12.7111 30.8708C14.3611 29.5908 16.7811 30.5108 17.2111 32.5608C17.3111 33.0608 17.2311 33.6008 17.2311 34.1408C18.6511 34.5008 19.4311 35.4508 19.5611 36.9608C21.3011 36.8708 22.4011 37.6608 22.8711 39.3408C23.0011 39.2708 23.1111 39.2108 23.2211 39.1608C24.9411 38.3508 26.9411 39.3308 27.2411 41.2008C27.3411 41.8208 27.6611 42.1008 28.1111 42.3708C28.8411 42.8108 29.7011 42.6508 30.1411 41.9808C30.5911 41.3008 30.4211 40.4508 29.7111 39.9608C29.1911 39.6008 28.6611 39.2608 28.1311 38.9108C27.4711 38.4708 26.7911 38.0408 26.1411 37.5808C25.7811 37.3308 25.7111 36.9208 25.9211 36.5908C26.1311 36.2608 26.5311 36.1708 26.9111 36.3708C27.0211 36.4308 27.1111 36.5008 27.2111 36.5708C28.7011 37.5608 30.1911 38.5508 31.6911 39.5308C32.6411 40.1508 33.8211 39.6508 33.9711 38.5608C34.0611 37.9108 33.7611 37.4308 33.2211 37.0808C31.6711 36.0608 30.1311 35.0408 28.5911 34.0108C28.1511 33.7108 28.0411 33.3008 28.3011 32.9408C28.5511 32.5908 28.9411 32.5308 29.3711 32.8108C29.8511 33.1208 30.3311 33.4408 30.8011 33.7508C32.2911 34.7408 33.7811 35.7308 35.2811 36.7108C36.2711 37.3508 37.4911 36.7808 37.5611 35.6508C37.6011 35.0408 37.3111 34.5908 36.8011 34.2608C34.5411 32.7708 32.2811 31.2808 30.0311 29.7708C29.4411 29.3808 28.8511 29.0008 28.1411 28.8508C27.8711 28.7908 27.6011 28.6608 27.3511 28.5308C25.9011 27.7908 24.9211 26.6208 24.3511 25.0408ZM39.6811 19.1308C39.4811 19.1608 39.3211 19.1808 39.1611 19.2008C38.5211 19.2908 37.8711 19.5208 37.2511 19.4508C34.8811 19.1508 32.5211 18.7708 30.1611 18.3808C28.8411 18.1708 27.5411 18.0108 26.2611 18.5708C24.1211 19.5008 21.9711 20.3808 19.8411 21.3308C19.4311 21.5108 19.0311 21.8308 18.7811 22.1908C17.8711 23.4808 17.0111 24.8108 16.1511 26.1308C15.8011 26.6708 15.9211 27.0908 16.5111 27.3808C17.4711 27.8608 18.6111 27.5808 19.2411 26.6908C19.7011 26.0408 20.1011 25.3508 20.5811 24.7108C20.7511 24.4808 21.0411 24.2708 21.3211 24.2008C22.3711 23.9408 23.4411 23.7408 24.5011 23.5208C25.2011 23.3708 25.4611 23.5308 25.6511 24.2308C26.3111 26.7008 28.7011 28.1608 31.2111 27.6808C32.2811 27.4708 33.1411 26.8808 34.0211 26.3008C34.5011 25.9808 34.9211 26.0208 35.1811 26.3908C35.4411 26.7708 35.3111 27.1808 34.8111 27.5208C33.8511 28.1708 32.9011 28.8108 31.6511 29.0508C31.8311 29.1908 31.9311 29.2708 32.0311 29.3408C33.6911 30.4408 35.3511 31.5308 37.0011 32.6308C37.5311 32.9908 38.0411 33.3808 38.5911 33.7808C39.2211 33.1308 39.7511 32.3308 40.1211 31.4308C40.2711 31.0708 40.4911 30.8308 40.9111 30.7808C41.1711 30.7508 41.4311 30.6808 41.7311 30.6208C41.0311 26.8008 40.3611 22.9808 39.6811 19.1308ZM28.2311 11.4608C28.2311 11.2108 28.2211 10.9808 28.2311 10.7608C28.2611 10.3308 28.5211 10.0508 28.9511 10.0408C29.9111 10.0208 30.8811 10.0208 31.8411 10.0408C32.2711 10.0508 32.5311 10.3308 32.5611 10.7608C32.5711 10.9908 32.5611 11.2308 32.5611 11.4708C33.7911 11.4308 34.7011 10.5408 34.7311 9.37078C34.7511 8.72078 34.7411 8.07078 34.7311 7.43078C34.7311 6.26078 34.1911 5.71078 33.0311 5.71078C28.5011 5.71078 23.9611 5.71078 19.4311 5.71078C17.8211 5.71078 16.2111 5.71078 14.6011 5.71078C13.6411 5.71078 13.0611 6.30078 13.0511 7.26078C13.0511 7.97078 13.0411 8.68078 13.0511 9.38078C13.0811 10.5508 14.0211 11.4608 15.2111 11.4608C15.2111 11.2708 15.2111 11.0808 15.2111 10.8808C15.2211 10.3108 15.4811 10.0408 16.0411 10.0408C16.9411 10.0308 17.8511 10.0308 18.7511 10.0408C19.2611 10.0508 19.5311 10.3208 19.5511 10.8208C19.5611 11.0308 19.5511 11.2308 19.5511 11.4608C22.4511 11.4608 25.3111 11.4608 28.2311 11.4608ZM19.5511 12.9408C19.5511 13.2008 19.5611 13.4208 19.5511 13.6408C19.5211 14.0708 19.2611 14.3508 18.8311 14.3608C17.8711 14.3808 16.9011 14.3808 15.9411 14.3608C15.4911 14.3508 15.2411 14.0608 15.2211 13.6008C15.2111 13.3808 15.2211 13.1608 15.2211 13.0508C14.4511 12.7908 13.7611 12.5608 13.0811 12.3308C13.0811 14.0508 13.0811 15.8308 13.0811 17.6308C14.0111 17.4908 14.9011 17.3508 15.7911 17.2108C16.8311 17.0508 17.8711 16.8708 18.9111 16.7508C20.3711 16.5708 21.7111 17.0008 22.9911 17.6408C23.6011 17.9508 24.1511 18.0408 24.7511 17.6508C25.0011 17.4908 25.3011 17.4108 25.5711 17.2908C26.6411 16.8308 27.7611 16.6108 28.9211 16.7508C29.9811 16.8808 31.0311 17.0708 32.0911 17.2308C32.9611 17.3608 33.8311 17.4908 34.7011 17.6108C34.7011 15.8008 34.7011 14.0308 34.7011 12.3308C34.0011 12.5608 33.3211 12.7908 32.5611 13.0408C32.5611 13.1708 32.5711 13.3908 32.5611 13.6108C32.5411 14.0608 32.2711 14.3408 31.8211 14.3508C30.8711 14.3608 29.9211 14.3608 28.9811 14.3508C28.5311 14.3408 28.2611 14.0608 28.2411 13.6108C28.2311 13.3908 28.2411 13.1708 28.2411 12.9308C25.3311 12.9408 22.4811 12.9408 19.5511 12.9408ZM4.46111 31.5008C5.30111 26.7408 6.13111 22.0308 6.97111 17.2708C6.25111 17.1408 5.56111 17.0208 4.83111 16.8908C3.99111 21.6608 3.16111 26.3808 2.32111 31.1308C3.06111 31.2608 3.72111 31.3808 4.46111 31.5008ZM40.8211 17.2708C41.6611 22.0408 42.4911 26.7608 43.3311 31.5108C44.0611 31.3808 44.7311 31.2608 45.4611 31.1308C44.6211 26.3708 43.7911 21.6408 42.9511 16.8908C42.2311 17.0208 41.5511 17.1408 40.8211 17.2708ZM18.1511 37.0808C18.0411 36.4408 17.7911 35.9908 17.2811 35.7408C16.7411 35.4708 16.1911 35.5008 15.7111 35.8908C14.5911 36.8108 13.4811 37.7308 12.3911 38.6708C11.7611 39.2108 11.7111 40.0808 12.2211 40.6908C12.7311 41.3008 13.6011 41.4008 14.2411 40.8708C15.3611 39.9608 16.4711 39.0408 17.5511 38.0808C17.8311 37.8308 17.9611 37.4108 18.1511 37.0808ZM15.8711 33.3908C15.8311 32.6008 15.5811 32.1608 15.0611 31.9008C14.5111 31.6308 13.9711 31.6908 13.5011 32.0808C12.5711 32.8408 11.6511 33.6208 10.7311 34.4008C10.1111 34.9308 10.0411 35.8208 10.5311 36.4208C11.0411 37.0408 11.9011 37.1508 12.5511 36.6308C13.5111 35.8608 14.4711 35.0708 15.3811 34.2408C15.6511 33.9908 15.7711 33.5708 15.8711 33.3908ZM25.9011 41.9908C25.8611 41.1808 25.6011 40.7308 25.0611 40.4708C24.5011 40.2008 23.9711 40.2908 23.5011 40.6708C22.7711 41.2708 22.0411 41.8808 21.3211 42.4908C20.7011 43.0308 20.6111 43.9008 21.1011 44.5108C21.6011 45.1408 22.4911 45.2508 23.1511 44.7208C23.9011 44.1208 24.6511 43.5108 25.3511 42.8608C25.6411 42.5908 25.7911 42.1808 25.9011 41.9908ZM19.8211 38.3908C19.6711 38.4608 19.3411 38.5308 19.1111 38.7108C18.3211 39.3308 17.5511 39.9808 16.8011 40.6508C16.2211 41.1608 16.1811 42.0208 16.6611 42.6008C17.1411 43.1908 17.9911 43.3408 18.6011 42.8708C19.4311 42.2308 20.2311 41.5408 21.0211 40.8508C21.4611 40.4608 21.5511 39.8108 21.3111 39.2708C21.0511 38.7008 20.5911 38.4408 19.8211 38.3908ZM26.7811 4.23078C26.7811 3.72078 26.7911 3.26078 26.7811 2.79078C26.7611 2.37078 26.4911 2.09078 26.0611 2.09078C24.6211 2.08078 23.1711 2.08078 21.7311 2.09078C21.3311 2.09078 21.0511 2.32078 21.0211 2.71078C20.9811 3.21078 21.0111 3.72078 21.0111 4.24078C22.9511 4.23078 24.8411 4.23078 26.7811 4.23078ZM16.6811 12.8908C17.1811 12.8908 17.6411 12.8908 18.0911 12.8908C18.0911 12.4108 18.0911 11.9708 18.0911 11.5108C17.6111 11.5108 17.1611 11.5108 16.6811 11.5108C16.6811 11.9808 16.6811 12.4208 16.6811 12.8908ZM29.7011 12.9008C30.2011 12.9008 30.6411 12.9008 31.1011 12.9008C31.1011 12.4208 31.1011 11.9708 31.1011 11.5108C30.6211 11.5108 30.1611 11.5108 29.7011 11.5108C29.7011 11.9808 29.7011 12.4308 29.7011 12.9008ZM24.7611 45.2908C25.3811 45.5608 25.9311 45.4708 26.3411 45.0508C26.7211 44.6608 26.8711 44.2108 26.7211 43.6208C26.0511 44.1908 25.4211 44.7208 24.7611 45.2908Z",
                fill: "white"
            }, void 0, false, {
                fileName: "[project]/src/app/components/ServicesFull.tsx",
                lineNumber: 166,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 165,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "True Copy Attestation"
        }, void 0, false),
        description: "True Copy Attestation is the process of verifying that a photocopy of a document is an exact and accurate representation of its original. ",
        link: "/services/True-Copy-Attestation"
    },
    {
        id: "08",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "56",
            height: "53",
            viewBox: "0 0 56 53",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1042_20)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M55.0352 52.0143C54.7135 52.6969 54.1659 52.9012 53.427 52.9012C36.1716 52.8882 18.9162 52.8925 1.66076 52.8925C0.413324 52.8925 0.0395294 52.5143 0.0395294 51.2492C0.0395294 50.8927 0.035183 50.5318 0.0395294 50.1753C0.0525688 49.0102 0.648033 48.3146 1.79984 48.1146C1.86939 48.1016 1.93458 48.0799 2.07367 48.0407C2.07367 47.6451 2.06498 47.2408 2.07367 46.8321C2.10409 45.7279 2.86907 44.9497 3.97307 44.9106C4.70762 44.8845 5.43782 44.8888 6.17237 44.8801C6.18541 44.8801 6.2028 44.8584 6.28973 44.7932C6.28973 44.3932 6.28973 43.9324 6.28973 43.4716C6.29407 42.3499 6.64179 41.8891 7.77187 41.55C7.77187 41.1804 7.77187 33.8376 7.77187 33.4463C7.77187 32.2986 7.9718 31.9073 8.56292 31.8986C9.17577 31.8899 9.3844 32.2899 9.3844 33.4724C9.3844 33.8289 9.3844 41.1413 9.3844 41.5413C10.2363 41.5413 11.0621 41.5413 11.9271 41.5413C11.9271 36.1113 11.9271 30.677 11.9271 25.1992C11.1099 25.1992 10.2798 25.1992 9.3844 25.1992C9.3844 25.3905 9.3844 25.5817 9.3844 25.7687C9.3844 28.9902 9.3844 32.216 9.3844 35.4374C9.3844 35.6157 9.39744 35.7983 9.36267 35.9722C9.27139 36.3852 9.01061 36.6417 8.57596 36.6373C8.14132 36.633 7.88053 36.3765 7.79795 35.9591C7.75883 35.7678 7.77621 35.5679 7.77621 35.3722C7.77621 31.9899 7.77621 28.6076 7.77621 25.2339C6.51574 24.734 6.29407 24.4079 6.29407 23.0689C6.29407 22.682 6.29407 22.2907 6.29407 21.8473C5.57256 21.8473 4.9119 21.8516 4.25559 21.8473C3.12986 21.8342 2.53874 21.243 2.5257 20.1213C2.52135 19.6605 2.5257 19.1997 2.5257 18.7128C2.05194 18.6823 1.62164 18.6867 1.20438 18.6258C0.548064 18.5258 0.191655 18.1432 0.135151 17.4824C0.10038 17.0911 0.130805 16.6955 0.109073 16.3043C0.0612617 15.5478 0.400285 15.0739 1.06964 14.7305C4.55984 12.9176 8.037 11.083 11.5229 9.25702C16.5908 6.58768 21.6805 3.93138 26.7485 1.24465C27.5743 0.805555 28.3002 0.76208 29.1173 1.249C30.1604 1.87068 31.2471 2.41846 32.3206 2.99233C32.6727 3.17927 32.9465 3.41403 32.9204 3.85747C32.8857 4.48351 32.2772 4.77914 31.6426 4.44873C30.5473 3.87921 29.4607 3.29665 28.3871 2.68366C28.0481 2.48802 27.796 2.50976 27.4613 2.68801C19.0596 7.11372 10.6536 11.5307 2.23883 15.9217C1.73465 16.1869 1.62164 16.4955 1.78246 17.0216C18.9422 17.0216 36.1194 17.0216 53.2966 17.0216C53.4487 16.4912 53.3357 16.1738 52.8141 15.8956C47.029 12.7959 37.4581 7.60933 31.686 4.48351C31.5122 4.39221 31.3383 4.29657 31.1819 4.17919C30.8428 3.91399 30.7516 3.5575 30.9558 3.17927C31.1601 2.79669 31.5122 2.69235 31.9208 2.80974C32.0903 2.85756 32.2467 2.9532 32.4032 3.04015C38.3144 6.23988 48.0287 11.5047 53.9529 14.6827C54.6701 15.0696 55.0439 15.5652 54.9743 16.3825C54.9526 16.6477 54.9743 16.9216 54.97 17.1868C54.9439 18.1867 54.4832 18.6475 53.4748 18.6736C53.1923 18.6823 52.9098 18.6736 52.5534 18.6736C52.5534 19.191 52.5577 19.6692 52.5534 20.1474C52.536 21.2343 51.9405 21.8299 50.8452 21.8473C50.2193 21.856 49.5934 21.856 48.9675 21.8603C48.9328 21.8603 48.9023 21.8821 48.785 21.9212C48.785 22.3125 48.785 22.7342 48.785 23.1559C48.785 24.4123 48.5025 24.8079 47.3202 25.2079C47.3202 30.6422 47.3202 36.0852 47.3202 41.5195C48.5459 41.9891 48.785 42.3369 48.785 43.6281C48.785 44.0193 48.785 44.415 48.785 44.8975C49.3805 44.8975 49.9498 44.9323 50.5105 44.8888C52.2882 44.7497 53.1532 45.8279 53.0054 47.3625C52.9837 47.5756 53.001 47.7886 53.001 48.0668C54.0225 48.0886 54.644 48.6624 55.0352 49.5406C55.0352 50.3666 55.0352 51.1883 55.0352 52.0143ZM13.5918 41.55C14.7262 41.8978 15.0522 42.3412 15.0565 43.502C15.0565 43.9454 15.0565 44.3889 15.0565 44.8584C15.9084 44.8584 16.6995 44.8584 17.5427 44.8584C17.5427 44.2715 17.5427 43.7237 17.5427 43.1716C17.547 42.589 17.7861 42.1282 18.2816 41.8239C18.5033 41.6891 18.7597 41.6152 18.9901 41.5195C18.9901 36.0591 18.9901 30.6205 18.9901 25.1948C17.8426 24.8209 17.5427 24.4123 17.5427 23.2298C17.5427 22.7863 17.5427 22.3429 17.5427 21.8777C16.6908 21.8777 15.8997 21.8777 15.0565 21.8777C15.0565 22.3385 15.0565 22.7689 15.0565 23.195C15.0565 24.3992 14.7436 24.8296 13.5918 25.1948C13.5918 30.6335 13.5918 36.0722 13.5918 41.55ZM41.4656 41.5587C41.4656 36.0809 41.4656 30.6335 41.4656 25.1905C40.3659 24.8688 40.0182 24.4036 40.0138 23.2819C40.0138 22.8211 40.0138 22.3646 40.0138 21.8951C39.1489 21.8951 38.3535 21.8951 37.5277 21.8951C37.5277 22.3298 37.5277 22.7211 37.5277 23.1124C37.5277 24.4384 37.3017 24.7688 36.0716 25.2253C36.0716 30.6552 36.0716 36.0939 36.0716 41.5282C37.3277 42.0108 37.5277 42.3151 37.5277 43.6976C37.5277 44.0845 37.5277 44.4715 37.5277 44.8627C38.3926 44.8627 39.1837 44.8627 40.0138 44.8627C40.0138 44.3715 40.0138 43.928 40.0138 43.4802C40.0182 42.3499 40.3659 41.8847 41.4656 41.5587ZM30.2083 41.5587C30.2083 36.0722 30.2083 30.6248 30.2083 25.1905C29.1173 24.8557 28.7957 24.421 28.787 23.3124C28.7826 22.8385 28.787 22.3646 28.787 21.8907C27.909 21.8907 27.131 21.8907 26.2834 21.8907C26.2834 22.3472 26.2834 22.7689 26.2834 23.195C26.2791 24.4297 26.0183 24.7992 24.8534 25.2166C24.8534 30.6639 24.8534 36.1156 24.8534 41.5587C25.9922 41.9325 26.2791 42.3325 26.2834 43.5324C26.2834 43.9715 26.2834 44.415 26.2834 44.8627C27.1527 44.8627 27.9438 44.8627 28.787 44.8627C28.787 44.3758 28.787 43.9324 28.787 43.4889C28.7913 42.3282 29.0999 41.9108 30.2083 41.5587ZM53.4053 51.2579C53.414 51.0927 53.4183 50.9883 53.4227 50.884C53.44 49.7015 53.44 49.7015 52.2795 49.7015C35.7456 49.7015 19.2117 49.7015 2.67783 49.7015C2.46485 49.7015 2.23449 49.6623 2.0389 49.7276C1.88677 49.7797 1.69118 49.9493 1.6738 50.0884C1.62164 50.4666 1.65641 50.8579 1.65641 51.2579C18.9336 51.2579 36.1412 51.2579 53.4053 51.2579ZM51.3885 48.0625C51.3885 47.8581 51.3885 47.719 51.3885 47.5799C51.3972 46.5148 51.3972 46.5148 50.3541 46.5148C35.2458 46.5148 20.1419 46.5104 5.0336 46.5191C3.57754 46.5191 3.65143 46.2191 3.69924 47.9581C3.69924 47.9886 3.73401 48.019 3.76879 48.0668C19.6116 48.0625 35.4631 48.0625 51.3885 48.0625ZM50.9234 18.7084C35.3153 18.7084 19.755 18.7084 4.17301 18.7084C4.17301 19.2258 4.17301 19.7127 4.17301 20.1952C19.7768 20.1952 35.3414 20.1952 50.9234 20.1952C50.9234 19.6953 50.9234 19.2344 50.9234 18.7084ZM23.1713 41.5674C23.1713 36.0765 23.1713 30.6378 23.1713 25.1948C22.3151 25.1948 21.498 25.1948 20.6765 25.1948C20.6765 30.6683 20.6765 36.1113 20.6765 41.5674C21.5197 41.5674 22.3194 41.5674 23.1713 41.5674ZM31.8773 41.5456C32.7553 41.5456 33.5811 41.5456 34.4069 41.5456C34.4069 36.0765 34.4069 30.6465 34.4069 25.2079C33.5463 25.2079 32.7205 25.2079 31.8773 25.2079C31.8773 30.6639 31.8773 36.0809 31.8773 41.5456ZM45.6425 41.5674C45.6425 36.107 45.6425 30.6509 45.6425 25.1861C44.7949 25.1861 43.9822 25.1861 43.1476 25.1861C43.1476 30.6596 43.1476 36.107 43.1476 41.5674C43.9909 41.5674 44.7906 41.5674 45.6425 41.5674ZM13.4136 21.8907C11.5489 21.8907 9.75385 21.8907 7.93703 21.8907C7.93703 22.4559 7.93703 22.982 7.93703 23.5037C9.78427 23.5037 11.5967 23.5037 13.4136 23.5037C13.4136 22.9472 13.4136 22.4342 13.4136 21.8907ZM41.6568 21.8821C41.6568 22.4603 41.6568 22.9733 41.6568 23.5124C43.4954 23.5124 45.3078 23.5124 47.129 23.5124C47.129 22.9515 47.129 22.4298 47.129 21.8821C45.2948 21.8821 43.4954 21.8821 41.6568 21.8821ZM13.4136 43.2324C11.575 43.2324 9.76254 43.2324 7.93703 43.2324C7.93703 43.7933 7.93703 44.315 7.93703 44.8497C9.78427 44.8497 11.5967 44.8497 13.4136 44.8497C13.4136 44.2889 13.4136 43.7759 13.4136 43.2324ZM47.142 43.2324C45.2817 43.2324 43.4823 43.2324 41.6612 43.2324C41.6612 43.7889 41.6612 44.315 41.6612 44.854C43.5084 44.854 45.3165 44.854 47.142 44.854C47.142 44.2932 47.142 43.7802 47.142 43.2324ZM19.19 21.8821C19.19 22.4559 19.19 22.982 19.19 23.5167C21.0199 23.5167 22.8149 23.5167 24.6361 23.5167C24.6361 22.9646 24.6361 22.4385 24.6361 21.8821C22.8149 21.8821 21.0199 21.8821 19.19 21.8821ZM35.8978 21.8821C34.0505 21.8821 32.2554 21.8821 30.4343 21.8821C30.4343 22.4385 30.4343 22.9646 30.4343 23.508C32.2685 23.508 34.0766 23.508 35.8978 23.508C35.8978 22.9602 35.8978 22.4429 35.8978 21.8821ZM19.1726 44.8671C21.0112 44.8671 22.8062 44.8671 24.6318 44.8671C24.6318 44.3106 24.6318 43.7846 24.6318 43.2368C22.8062 43.2368 20.9981 43.2368 19.1726 43.2368C19.1726 43.7846 19.1726 44.2976 19.1726 44.8671ZM35.8891 44.8714C35.8891 44.3019 35.8891 43.7759 35.8891 43.2368C34.0549 43.2368 32.2467 43.2368 30.4473 43.2368C30.4473 43.7976 30.4473 44.3237 30.4473 44.8714C32.2685 44.8714 34.0462 44.8714 35.8891 44.8714Z",
                        fill: "white"
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 180,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1042_20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "52",
                            fill: "white",
                            transform: "translate(0.0352783 0.901367)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 185,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 184,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 183,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 179,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Police Clearence Certificate (PCC)"
        }, void 0, false),
        description: "A Police Clearance Certificate, often recognised as a Good Conduct Certificate, stands as an essential proof of a person’s clean background. ",
        link: "/services/Police-Clearence-Certificate"
    },
    {
        id: "09",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 201,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 203,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 204,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 205,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 200,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 209,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 208,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 207,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 199,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Translation Services"
        }, void 0, false),
        description: "In a country as globally connected as the UAE, translation plays an important role in legal, corporate, and immigration processes. ",
        link: "/services/Translation-Services"
    },
    {
        id: "10",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 226,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 227,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 228,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 229,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 225,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 234,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 233,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 232,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 224,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Country Specific Attestation Services"
        }, void 0, false),
        description: "Every country follows its own unique procedures for document attestation, and understanding these differences is essential to completing the process correctly. ",
        link: "/services/Country-Specific-Attestation-Services"
    },
    {
        id: "11",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 251,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 252,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 253,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 254,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 255,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 250,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 259,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 258,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 257,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 249,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "UAE-Issued Document"
        }, void 0, false),
        description: "Documents issued within the UAE—whether educational, personal, legal, or commercial—often require attestation before they can be used outside the country.  ",
        link: "/services/UAE-Issued-Document"
    },
    {
        id: "12",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 276,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 277,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 278,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 279,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 280,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 275,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 284,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 283,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 282,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 274,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Family Visa Documentation Support"
        }, void 0, false),
        description: "Family visa documentation is one of the most sensitive areas of attestation because it directly affects the ability of families to reunite and live together. ",
        link: "/services/Family-Visa-Documentation-Support"
    },
    {
        id: "13",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 301,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 302,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 303,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 304,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 305,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 300,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 309,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 308,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 307,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 299,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Business Setup Services"
        }, void 0, false),
        description: "The UAE is a highly attractive business destination globally, thanks to its dynamic economy, strategic location, tax benefits, and global connectivity.",
        link: "/services/Business-Setup-Services"
    },
    {
        id: "14",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 326,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 327,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 328,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 329,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 330,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 325,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 334,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 333,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 332,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 324,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Pro Services"
        }, void 0, false),
        description: "Public Relations Officer (PRO) services are essential to navigating the UAE’s government processes. ",
        link: "/services/Pro-Services"
    },
    {
        id: "15",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "55",
            height: "59",
            viewBox: "0 0 55 59",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_1053_1525)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20.1067 40.8658C20.6835 41.7199 21.1986 42.4865 21.7188 43.2531C23.578 45.9954 25.463 48.7274 27.2965 51.4852C29.0528 54.1246 27.9403 57.4225 24.9892 58.4464C23.0063 59.1358 20.8432 58.3486 19.5402 56.4398C16.9805 52.6839 14.4259 48.9178 11.8714 45.1619C11.7478 44.9767 11.6139 44.7966 11.4697 44.5908C10.3057 45.3111 9.09023 45.7382 7.746 45.7793C3.45581 45.9028 -0.108199 42.3887 -4.27689e-05 38.0875C0.0617608 35.6024 1.16392 33.6576 3.19829 32.2427C4.69188 31.2034 6.22151 30.2156 7.70995 29.1711C8.04472 28.9345 8.36919 28.5949 8.54945 28.2296C11.4594 22.3848 14.3435 16.5246 17.2328 10.6747C17.9333 9.25984 19.1127 8.5241 20.6372 8.34917C22.5686 8.12279 24.3093 8.76077 25.9626 9.65087C28.9807 11.2767 31.4271 13.592 33.585 16.2159C36.7422 20.0644 39.204 24.2936 40.4967 29.1351C41.0427 31.1777 41.3259 33.2614 40.8933 35.3709C40.6718 36.4462 40.2392 37.4289 39.4564 38.2213C38.6787 39.0084 37.7465 39.42 36.6289 39.5075C31.2777 39.9191 25.9317 40.3513 20.5805 40.7835C20.4569 40.7938 20.3282 40.8246 20.1067 40.8658ZM18.4689 14.9811C18.6234 15.8609 18.7264 16.9877 19.0251 18.0527C20.9153 24.7464 24.6544 30.2413 30.0056 34.6506C31.4889 35.87 33.1421 36.8372 35.058 37.2643C36.0726 37.4907 36.8864 37.1614 37.5971 36.4822C38.1791 35.9266 38.4778 35.2114 38.622 34.4345C38.9259 32.819 38.7868 31.2086 38.3233 29.6548C36.2992 22.8376 32.4314 17.2604 26.833 12.8819C25.53 11.8632 24.0776 11.0709 22.4449 10.685C20.4054 10.2065 18.9633 11.1584 18.6183 13.2215C18.541 13.7206 18.5359 14.2351 18.4689 14.9811ZM30.4021 37.7685C23.2587 32.572 18.6286 25.7754 16.4706 17.2758C16.4191 17.3581 16.3727 17.4199 16.3418 17.4868C14.4414 21.361 12.5409 25.2352 10.6302 29.1042C10.4757 29.4181 10.5529 29.6188 10.728 29.8709C12.6388 32.6749 14.5547 35.4687 16.4345 38.2933C16.7333 38.7409 17.032 38.8541 17.5419 38.8078C19.8286 38.5968 22.1153 38.4373 24.4021 38.2521C26.3798 38.0926 28.3575 37.9331 30.4021 37.7685ZM8.85847 31.1211C7.35458 32.1398 5.87129 33.1174 4.42406 34.1464C2.03432 35.8391 1.5502 38.8129 3.23949 41.262C4.90304 43.6853 7.84386 44.3027 10.2748 42.7129C11.6242 41.8331 12.9426 40.907 14.2766 40.0014C14.4156 39.9088 14.5444 39.8059 14.6937 39.6927C12.7418 36.827 10.8156 33.9972 8.85847 31.1211ZM13.3444 43.3457C14.0139 44.3284 14.6371 45.2494 15.2654 46.1703C17.3307 49.2111 19.3908 52.2518 21.4612 55.2873C22.1102 56.2392 23.0681 56.6405 24.0518 56.3987C25.7514 55.9819 26.4055 54.14 25.3755 52.6171C22.8724 48.9178 20.3591 45.2185 17.8457 41.5244C17.511 41.0304 17.0062 40.8864 16.5067 41.2157C15.456 41.8948 14.4311 42.61 13.3444 43.3457Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 351,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M43.1285 16.4577C42.4126 16.4577 42.047 16.2005 41.8615 15.7117C41.6761 15.2229 41.8615 14.7187 42.356 14.3894C43.4581 13.6537 44.5706 12.9334 45.6779 12.2079C47.0839 11.287 48.49 10.3609 49.9012 9.43989C50.6016 8.98198 51.2608 9.04887 51.6523 9.61482C52.054 10.1962 51.8686 10.8651 51.1475 11.3384C48.696 12.9488 46.2444 14.5541 43.7878 16.1542C43.5405 16.3085 43.2521 16.4011 43.1285 16.4577Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 352,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M44.9773 21.6542C46.4863 21.9269 48.0932 22.2099 49.6949 22.498C51.0907 22.7501 52.4915 23.0074 53.8924 23.2492C54.6289 23.3778 55.0821 23.882 54.9997 24.5046C54.907 25.1889 54.289 25.6056 53.5165 25.4667C50.7765 24.9779 48.0365 24.4789 45.2966 23.9849C45.0339 23.9386 44.7713 23.9026 44.5189 23.8306C43.9266 23.6659 43.5764 23.1463 43.6691 22.5958C43.7566 21.999 44.2459 21.6234 44.9773 21.6542Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 353,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M39.2656 1.88181C39.0339 4.13533 38.8021 6.394 38.5703 8.65267C38.5137 9.19805 38.4622 9.74342 38.3952 10.2888C38.3077 10.9782 37.8081 11.3898 37.1489 11.3229C36.536 11.2612 36.1188 10.757 36.1858 10.0778C36.4587 7.2738 36.742 4.4749 37.0407 1.67086C37.1077 1.02258 37.6484 0.631562 38.2819 0.698447C38.8742 0.765333 39.2811 1.25411 39.2656 1.88181Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 354,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M26.6117 19.2617C29.2744 19.2617 31.592 20.8875 32.4418 23.3572C33.2813 25.7908 32.4882 28.4919 30.4538 30.0972C30.2478 30.2567 30.0212 30.4213 29.7791 30.4985C29.2693 30.6683 28.7233 30.4213 28.4761 29.948C28.2186 29.4643 28.3267 28.8984 28.8109 28.5331C29.7122 27.8488 30.3148 26.9947 30.459 25.8577C30.6495 24.3296 30.1191 23.0896 28.8675 22.2047C27.616 21.3249 26.2666 21.2683 24.8864 21.932C24.7164 22.0143 24.5619 22.1275 24.3919 22.2098C23.8305 22.4825 23.2125 22.3127 22.9035 21.7982C22.5996 21.294 22.7438 20.6612 23.2434 20.2907C24.0932 19.6733 25.4323 19.2617 26.6117 19.2617Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 355,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 350,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_1053_1525",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "55",
                            height: "58",
                            fill: "white",
                            transform: "translate(0 0.693359)"
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                            lineNumber: 359,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 358,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                    lineNumber: 357,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 349,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0)),
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: "Golder Visa Support Services"
        }, void 0, false),
        description: "The UAE Golden Visa represents one of the most prestigious residency programs available today. ",
        link: "/services/Golder-Visa-Support-Services"
    }
];
const ServicesFull = ()=>{
    const data = ServicesFullDataEn;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-14 lg:py-24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-[1050px] mx-auto px-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid lg:grid-cols-3 sm:grid-cols-2  md:gap-5 gap-3 relative",
                children: data.map((choose)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-3xl  p-3 sm:p-7  transition-all duration-300 relative top-0 hover:top-[-6px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "md:w-22 w-14 md:h-22 h-14 flex items-center justify-center rounded-full md:p-4 p-3 border border-[#46ADC0]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "38",
                                    height: "44",
                                    viewBox: "0 0 38 44",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                            clipPath: "url(#clip0_1541_5087)",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M0.578955 7.69562C0.578955 6.90056 0.56722 6.11719 0.578955 5.34551C0.614159 3.07724 2.05755 1.39357 4.24023 1.03112C4.5336 0.972656 4.82697 0.972656 5.12034 0.972656C13.9802 0.972656 22.8282 0.972656 31.6881 0.972656C34.4105 0.972656 36.2177 2.78493 36.2294 5.5092C36.2294 7.29809 36.2294 9.08698 36.2294 10.8642C36.2294 12.1737 35.5488 12.8401 34.2345 12.8401C32.6621 12.8401 31.0896 12.8401 29.4467 12.8401C29.4467 13.682 29.4467 14.4654 29.4467 15.1318C28.3788 15.2604 27.3579 15.2604 26.4074 15.5176C21.7721 16.7921 20.0588 22.8252 23.239 26.403C23.4032 26.5901 23.5089 26.9175 23.4854 27.163C23.3798 28.227 23.2155 29.2909 23.0512 30.3549C23.0277 30.5186 22.8869 30.7174 22.7461 30.8226C21.5257 31.7229 20.9037 32.9038 20.8451 34.4121C20.8333 34.5875 20.6573 34.833 20.493 34.9149C18.592 35.8619 17.5358 37.3702 17.395 39.4748C17.3129 40.7258 17.3011 41.9886 17.9465 43.2163C17.6884 43.2163 17.4889 43.2163 17.2894 43.2163C13.0062 43.2163 8.72295 43.1578 4.43972 43.2396C2.11622 43.2981 0.54375 41.6846 0.555485 39.3812C0.602425 29.6651 0.578955 19.949 0.578955 10.2328C0.578955 9.99897 0.578955 9.76512 0.578955 9.53128M13.0062 5.09997C10.6475 5.09997 8.28876 5.08828 5.93005 5.09997C4.75656 5.09997 4.05247 5.81319 4.05247 6.97071C4.04074 7.88269 4.04074 8.79468 4.05247 9.70666C4.06421 10.7356 4.79177 11.4722 5.82444 11.4722C10.6123 11.4839 15.4118 11.4839 20.1996 11.4722C21.2206 11.4722 21.9481 10.7356 21.9716 9.70666C21.9833 8.85314 21.9833 7.98792 21.9716 7.1344C21.9716 5.75473 21.3144 5.09997 19.918 5.09997C17.618 5.08828 15.3062 5.08828 13.0062 5.09997ZM34.4457 11.0629C34.4457 9.00514 34.5162 6.95902 34.4223 4.93628C34.3636 3.67353 33.2019 2.74986 31.958 2.74986C30.6906 2.74986 29.5288 3.68523 29.4702 4.98305C29.388 6.99409 29.4467 9.01683 29.4467 11.0746C31.1248 11.0629 32.7794 11.0629 34.4457 11.0629ZM12.4194 13.9743C11.2459 13.9743 10.0842 13.9743 8.9107 13.9743C7.60813 13.9743 6.3173 13.9743 5.01473 13.9743C4.43972 13.9743 4.07594 14.3017 4.05247 14.8044C4.029 15.3189 4.40452 15.6813 4.99126 15.7164C5.08514 15.7164 5.17902 15.7164 5.26116 15.7164C10.0372 15.7164 14.8016 15.7164 19.5777 15.7164C19.7889 15.7164 20.0236 15.7164 20.2231 15.6463C20.8451 15.4358 21.0445 14.6641 20.5517 14.2432C20.3405 14.0678 19.9884 13.986 19.7068 13.9743C17.2894 13.9743 14.8485 13.9743 12.4194 13.9743ZM11.4924 23.1643C11.0347 23.1643 10.5771 23.1643 10.1194 23.1643C8.41784 23.1643 6.71628 23.1526 5.01473 23.1643C4.31064 23.1643 3.87645 23.7255 4.09941 24.3101C4.28717 24.7895 4.68615 24.9181 5.15555 24.9064C7.27956 24.9064 9.39183 24.9064 11.5158 24.9064C13.6046 24.9064 15.6817 24.9064 17.7705 24.9064C18.2751 24.9064 18.6858 24.7544 18.8384 24.2516C19.0261 23.667 18.5685 23.1643 17.8409 23.1643C15.7287 23.1643 13.6046 23.1643 11.4924 23.1643ZM10.0725 27.7593C8.42957 27.7593 6.77496 27.7593 5.13208 27.7593C4.42799 27.7593 4.04074 28.075 4.05247 28.6362C4.05247 29.1857 4.45146 29.5131 5.15555 29.5131C8.42957 29.5131 11.7036 29.5131 14.9776 29.5131C15.67 29.5131 16.0572 29.1857 16.0572 28.6245C16.0572 28.075 15.67 27.771 14.9659 27.771C13.3347 27.7593 11.7036 27.7593 10.0725 27.7593ZM9.13367 18.5693C7.78416 18.5693 6.42291 18.5693 5.0734 18.5693C4.41625 18.5693 4.04074 18.8967 4.05247 19.4345C4.05247 19.9723 4.43972 20.3114 5.08514 20.3114C7.79589 20.3231 10.4949 20.3231 13.2057 20.3114C13.8393 20.3114 14.2501 19.9373 14.2501 19.4228C14.2501 18.8967 13.8511 18.5693 13.2057 18.5576C11.8444 18.5693 10.4832 18.5693 9.13367 18.5693ZM7.24435 32.3543C6.49332 32.3543 5.74229 32.3426 4.99126 32.3543C4.41625 32.366 4.05247 32.6934 4.04074 33.1961C4.029 33.7223 4.39278 34.0964 4.99126 34.0964C6.43465 34.1081 7.87804 34.1081 9.32142 34.0964C9.9199 34.0964 10.3072 33.7223 10.3072 33.2195C10.3072 32.705 9.9199 32.366 9.32142 32.3543C8.62907 32.3543 7.93671 32.3543 7.24435 32.3543Z",
                                                    fill: "#46ADC0"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                                                    lineNumber: 393,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M34.07 36.049C34.7624 36.3179 35.4078 36.4699 35.9359 36.7973C36.9686 37.4286 37.4849 38.4108 37.5436 39.6268C37.567 40.0477 37.5553 40.4686 37.5436 40.8895C37.5436 42.4329 36.7339 43.2396 35.1731 43.2396C32.0869 43.2396 28.9889 43.2396 25.9026 43.2396C24.424 43.2396 22.9337 43.2396 21.4551 43.2396C19.9765 43.2279 19.155 42.4095 19.1433 40.9246C19.1433 40.7024 19.1433 40.492 19.1433 40.2698C19.1433 37.8379 20.176 36.5985 22.6168 36.1776C22.6168 35.6281 22.6051 35.0668 22.6168 34.5056C22.6403 33.3364 23.1918 32.518 24.2597 32.0152C24.4357 31.9333 24.6352 31.7112 24.6704 31.5358C24.9169 29.8638 25.1281 28.1802 25.3628 26.5082C25.4097 26.1925 25.3393 25.9821 25.0811 25.7599C22.9454 23.9359 22.7576 20.6972 24.647 18.6277C26.5597 16.5348 29.8455 16.453 31.8639 18.4406C33.8706 20.4166 33.8706 23.6436 31.8052 25.5728C31.3945 25.9587 31.2889 26.2977 31.371 26.8356C31.6175 28.3789 31.8052 29.934 32.0047 31.489C32.0399 31.7814 32.1455 31.9217 32.4272 32.0269C33.4716 32.4595 34.0231 33.2662 34.0583 34.4004C34.0818 34.9616 34.07 35.5462 34.07 36.049ZM28.32 41.4741C30.6083 41.4741 32.8848 41.4624 35.1731 41.4858C35.619 41.4858 35.8185 41.3455 35.7833 40.8895C35.7599 40.492 35.7951 40.0828 35.7716 39.6852C35.7364 38.7265 35.0206 38.0132 34.0583 37.9665C33.8001 37.9548 33.542 37.9665 33.2955 37.9665C29.7986 37.9665 26.3133 37.9665 22.8163 37.9665C21.6194 37.9665 20.9153 38.668 20.8801 39.8606C20.8683 40.1646 20.9035 40.4803 20.8801 40.7843C20.8449 41.2987 21.0326 41.4975 21.5724 41.4858C23.8255 41.4624 26.0786 41.4741 28.32 41.4741ZM29.6225 26.9057C28.7424 26.9057 27.9327 26.9057 27.0761 26.9057C26.8648 28.5076 26.6419 30.1328 26.4189 31.7814C27.745 31.7814 29.0006 31.7814 30.2797 31.7814C30.0567 30.1211 29.8338 28.5076 29.6225 26.9057Z",
                                                    fill: "#46ADC0"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                                                    lineNumber: 394,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M5.83618 6.8772C10.624 6.8772 15.3884 6.8772 20.1762 6.8772C20.1762 7.82426 20.1762 8.74794 20.1762 9.695C15.4001 9.695 10.6357 9.695 5.83618 9.695C5.83618 8.75963 5.83618 7.83595 5.83618 6.8772Z",
                                                    fill: "#46ADC0"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                                                    lineNumber: 395,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                                            lineNumber: 392,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                                                id: "clip0_1541_5087",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                                    width: "37",
                                                    height: "42.2787",
                                                    fill: "white",
                                                    transform: "translate(0.55542 0.972656)"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                                                    lineNumber: 399,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/ServicesFull.tsx",
                                                lineNumber: 398,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/ServicesFull.tsx",
                                            lineNumber: 397,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/components/ServicesFull.tsx",
                                    lineNumber: 391,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/ServicesFull.tsx",
                                lineNumber: 390,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg md:text-xl leading-tight font-semibold mt-6 lg:mt-12 min-h-[50px]",
                                children: choose.title
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/ServicesFull.tsx",
                                lineNumber: 406,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm mt-4 text-[#404040] font-normal ",
                                children: choose.description
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/ServicesFull.tsx",
                                lineNumber: 409,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$AnimatedButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: choose.link,
                                label: "Learn More",
                                className: "w-fit transparent-btn2 transparent-btn3 mt-6"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/ServicesFull.tsx",
                                lineNumber: 412,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, choose.id, true, {
                        fileName: "[project]/src/app/components/ServicesFull.tsx",
                        lineNumber: 385,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/app/components/ServicesFull.tsx",
                lineNumber: 383,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/components/ServicesFull.tsx",
            lineNumber: 381,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/app/components/ServicesFull.tsx",
        lineNumber: 380,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ServicesFull;
}),
"[project]/src/app/components/Hero2.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
const Hero2 = ({ heading_en, breadcrumbPosition = "left" })=>{
    // Choose based on language
    const heading = heading_en;
    const breadcrumbText = heading_en;
    // Breadcrumb alignment
    const breadcrumbAlignClass = breadcrumbPosition === "center" ? "justify-center" : breadcrumbPosition === "right" ? "justify-end" : "justify-start";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "mt-[95px] rounded-3xl overflow-hidden w-full bg-[var(--green)]  flex flex-col justify-center items-center text-center relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `hero2-bg absolute inset-0 bg-[url('/hero2.png')] bg-[cover]`
            }, void 0, false, {
                fileName: "[project]/src/app/components/Hero2.tsx",
                lineNumber: 32,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 20
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.5
                },
                className: `relative z-10 py-8 lg:py-14 flex flex-col justify-center items-center w-full max-w-7xl min-h-[200px] lg:min-h-[340px] px-6 items-${breadcrumbPosition} text-${breadcrumbPosition}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-3xl lg:text-5xl leading-tight font-medium text-center text-white max-w-[700px]",
                        children: heading
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Hero2.tsx",
                        lineNumber: 41,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    (breadcrumbText ?? heading) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `flex items-center gap-2 breadcrumb mt-3 lg:mt-6 px-7 py-[2px] bg-[#D5E5E3] rounded-3xl text-black ${breadcrumbAlignClass}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "text-sm lg:text-md  my-1 font-light",
                                children: "Home"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Hero2.tsx",
                                lineNumber: 48,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "18",
                                    height: "18",
                                    viewBox: "0 0 18 18",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M10.1025 4.10249C10.208 3.99716 10.3509 3.93799 10.5 3.93799C10.6491 3.93799 10.792 3.99716 10.8975 4.10249L15.3975 8.60249C15.5028 8.70796 15.562 8.85093 15.562 8.99999C15.562 9.14906 15.5028 9.29202 15.3975 9.39749L10.8975 13.8975C10.846 13.9528 10.7839 13.9971 10.7149 14.0278C10.6459 14.0586 10.5714 14.0751 10.4959 14.0764C10.4204 14.0778 10.3453 14.0639 10.2753 14.0356C10.2053 14.0073 10.1416 13.9652 10.0882 13.9118C10.0348 13.8584 9.9927 13.7947 9.96441 13.7247C9.93612 13.6546 9.92222 13.5796 9.92356 13.5041C9.92489 13.4286 9.94142 13.3541 9.97216 13.2851C10.0029 13.2161 10.0472 13.154 10.1025 13.1025L13.6425 9.56249H3C2.85082 9.56249 2.70774 9.50323 2.60225 9.39774C2.49676 9.29225 2.4375 9.14918 2.4375 8.99999C2.4375 8.85081 2.49676 8.70774 2.60225 8.60225C2.70774 8.49676 2.85082 8.43749 3 8.43749H13.6425L10.1025 4.89749C9.99716 4.79202 9.93799 4.64906 9.93799 4.49999C9.93799 4.35093 9.99716 4.20796 10.1025 4.10249Z",
                                        fill: "black"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Hero2.tsx",
                                        lineNumber: 54,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Hero2.tsx",
                                    lineNumber: 53,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Hero2.tsx",
                                lineNumber: 52,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm lg:text-md  my-1 font-normal",
                                children: breadcrumbText
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Hero2.tsx",
                                lineNumber: 60,
                                columnNumber: 25
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/Hero2.tsx",
                        lineNumber: 47,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/Hero2.tsx",
                lineNumber: 36,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Hero2.tsx",
        lineNumber: 31,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Hero2;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__9ba4d2b0._.js.map